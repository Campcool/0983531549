# AI-README｜潔淨坊清潔工作室（0983531549）AI 協作交接文件

> **⚠️ 所有 AI 協作規則（必讀）**
> 1. **動手前**：先完整讀完本檔案，了解架構、內容邊界、已知陷阱、進度與待辦。
> 2. **動手後**：完成任何修改，必須更新本檔案的「進度紀錄」與「待辦清單」，再一併 commit。
> 3. 本檔案是唯一的交接依據，寫給 AI 看：請保持精確、可執行、不留模糊描述。
> 4. **所有時間戳一律台灣時間（Asia/Taipei, UTC+8）**。
> 5. **不要把「已完成」寫在沒有實測的項目上**。未驗的事項寫進「本輪明確未驗」。

最後更新：2026-10-05（Codex）— 依業主新授權新增獨立的 Google Ads AI 生成情境素材批次：5 種服務 × 橫／方／直三比例，共 15 張；與 2026-10-03 的實拍素材完全分開保存並標記來源。
（前一筆 2026-10-03 Codex）— 新增 Google Ads 實拍圖片素材產生器與 14 個可上傳素材；全程只做裁切、調色與一處臉部模糊，未使用生成式影像、疊字或拼貼。
（前一筆 2026-09-29 晚 Codex）— H2 覆審結案；首頁與案例頁已改用共用 `SiteHeader`，commit `bba5150` 已部署正式站並由業主確認。
（前一筆 2026-09-29 晚 Claude）— 依業主指示移除一般居家清潔重複的冰箱照（原 04／05 同檔），照片總數 105→104、首頁數字同步。
（前一筆 2026-09-29 晚 Claude）— H16 首頁數字錨點更新為 105 張／12 相簿並修正三位數溢出；前一筆為依審查結果實作 H3、H7–H15：水垢相簿併入一般居家（12 相簿）、案例卡改用縮圖（375px 捲完 3.76→0.72 MB）、23 張大圖壓縮（7.31→4.22 MB）、色章對比、`#album-finder` 捲動、無障礙與無結果 LINE。**H2 已由 Codex 覆審結案，現況見第 6 節（六）**。
（前一輪 2026-09-29 Claude）— 唯讀審查 `f18a808...5bc9b74` 案例頁改版（結論：維持上線，P2×3、P3×4 排給 Codex 為 H9–H14），並記錄業主要求把「重水地區水垢處理」併入「一般居家清潔」（H15）。本輪只改文件。
（前一輪 2026-09-29 Codex）— 重設案例頁標籤與案例卡視覺：三組篩選改為白底卡面搭配三色上緣識別線與規整分段按鈕，分類改深色方角色章、複合標籤改淺色圓膠囊，移除前台案件／照片／影片數字並完成互動與四種寬度（375／768／882／1280）驗證。
（前一輪 2026-09-28 Claude）— 修正首頁與案例頁 header 三處不一致（首頁加電話鈕、案例頁加「← 回首頁」、案例頁 logo 尺寸對齊首頁），並補量測 1280／1366／1440 無重疊。
（前一輪 2026-09-28 Codex）— 案例頁改為「服務情境 × 空間部位 × 處理需求」複合標籤速查，13 個相簿可交叉篩選，並收斂原本四大分類與多色索引造成的視覺雜訊。
（前一輪 2026-09-28 Codex）— 覆審兩個新相簿：修正 `height:auto` 導致 lazy 圖片零高度不載入，並將 38 張部署照片縮至最長邊 1600px、JPEG quality 82（20.43→9.45 MB）。
（前一輪 2026-09-28 Claude）— 新增 38 張一般居家清潔＋退租入住清潔照片（LINE 拼圖），並加入 isComposite 旗標與 contain 顯示。
（前一輪 2026-09-24 Claude）— 依業主要求把 OG 服務地區改為「林口・龜山・基隆・雙北・桃園」（三頁 meta ＋ 重產 OG 圖），並新增具名的「退租入住」需求情境卡。
（前一輪 2026-09-13 Codex）— 依業主要求做整體 UI/UX 高質感強化：首頁首屏改為價值主張優先、補 67 張實拍／11 個相簿／31 則評論等數字錨點，並把數字錨點補成 4 個吸睛彩色數據磚；加入詢問前風險逆轉三句，案例頁首屏補相簿統計並同步 DESIGN.md／sitemap。
（前一輪 2026-09-12 Claude 上架前全站稽核並修正 P1×5／P2×10；同日 Codex 補入「油漆清潔」完工照，案例頁為 11 個相簿／67 張照片／2 支影片。）

**⚠️ 兩件事卡在業主帳號，做完才會有效果：**
1. **G1｜Google 商家的「網站」欄位仍指向 FB，不是 `jjf.tw`** — 5 分鐘可改，是整份清單投報最高的一項。
2. **G6｜GA4 Measurement ID 尚未填入** — 埋點已完成但還沒開始收數據。

**📋 H 系列待辦**（2026-09-29 Codex 結案：H1–H16 均已完成；H2 已覆審、修正、部署並由業主確認）

正式站版本：`bba5150`；GitHub Pages run `36533094857` 成功。H2 結論為維持上線，不需回退。

| # | 項目 | 位置 | 完成條件 |
|---|---|---|---|
| H1 | ✅ 原案例頁「← 回首頁」字級修正已完成；`bba5150` 後由共用 header 的首頁 logo 與六項導覽取代 | `src/SiteHeader.jsx`、`src/style.css` | 2026-09-29 完成並由業主確認 |
| H2 | ✅ 覆審 `5740012` 與 `652060a...23426ed` 後，依業主決定把首頁／案例頁 header 合併為共用 `SiteHeader`；375／820／1280／1440 production preview 與正式站通過 | `src/SiteHeader.jsx`、`src/main.jsx`、`src/cases.jsx`、`src/style.css` | 2026-09-29 覆審結案；`bba5150` 已部署 |
| H3 | ✅ 819／820／1024／1278 時由底部 dock 承接聯絡，1280 起 header 顯示三鈕並隱藏 dock；無水平溢出。1279 分數像素邊界與 dock 遮住數字磚列為非阻斷後續，不影響 H2 結案 | `src/style.css` | 2026-09-29 完成；限制見第 6 節（六） |
| H4 | ✅ Claude 已覆審 E2 標籤（見第 6 節「2026-09-28（六）」）；H5、H6、H7 後續均已完成 | `src/cases.jsx` `tags` | 2026-09-29 完成 |
| H5 | ✅ `grease-kitchen` 的 `tags` 已補「居家」與「商用」；「居家＋廚房」實測會出現廚房重油汙 | `src/cases.jsx:96` | 2026-09-29 完成 |
| H6 | ✅ 標籤用字已統一為「重油汙」 | `src/cases.jsx` | 2026-09-29 完成 |
| H8 | ✅ 2026-09-29 Claude 以 sharp（mozjpeg）將 23 張最長邊 >1600px 照片縮至 1600px、q82：7.31→4.22 MB；檔名不變。含 H15 搬入、現為 general-home-cleaning-11..14 的水垢照 | `public/cases/` | 2026-09-29 完成 |
| H9 | ✅ 2026-09-29 Claude：每相簿第一張另存 720×450 `-01-thumb.jpg`（q78，12 張共 0.55 MB），卡片改用 `thumbOf()`；375px 捲完卡片列表圖片 3.76→0.72 MB（含首屏大圖） | `src/cases.jsx`、`public/cases/*/*-01-thumb.jpg` | 2026-09-29 完成 |
| H10 | ✅ 2026-09-29 Claude：色章背景 `color-mix` 88%→70%，白字 4.41→5.46:1 | `src/style.css` `.album-index-category` | 2026-09-29 完成 |
| H11 | ✅ 2026-09-29 Claude：掛載時 `#album-finder` 補 `scrollIntoView`；375／768／882／1280／1440 標題皆落在 header 下方 | `src/cases.jsx` | 2026-09-29 完成 |
| H12 | ✅ 2026-09-29 Claude：移除兩處 `aria-label`；卡片名稱實測為「重點清潔 洗地打蠟 居家 商用 地板 洗地打蠟 查看現場照片」 | `src/cases.jsx` | 2026-09-29 完成 |
| H13 | ✅ 2026-09-29 Claude：無結果畫面加「LINE 傳照片詢問」（`line-primary`，50px）＋原「查看全部案例」 | `src/cases.jsx`、`src/style.css` `.case-filter-empty-actions` | 2026-09-29 完成 |
| H14 | ✅ 2026-09-29 Claude：h2 改 `clamp(30px, 5vw, 58px)`；375 為 30<34、768 為 38.4<42 | `src/style.css` | 2026-09-29 完成 |
| H15 | ✅ 2026-09-29 Claude 依業主確認完成合併：12 個相簿，一般居家清潔現為 14 張並加「水垢」標籤，`#scale-removal` 自動開啟一般居家清潔 | 見第 6 節「2026-09-29（三）（五）」 | 2026-09-29 完成並覆審 |
| H7 | ✅ 2026-09-29 業主決定「洗地打蠟」標「居家＋商用」，Claude 已改 | `src/cases.jsx` | 2026-09-29 完成 |
| H16 | ✅ 2026-09-29 業主決定更新數字：首頁數字錨點現為 104 張／12 個相簿，並修正三位數溢出（見第 6 節（四）（五）） | `src/main.jsx`、`src/style.css` `.hero-proof-list` | 2026-09-29 完成並覆審 |

**G4（CSR 對 AI 檢索不可見）業主指定三方決議**：業主、Codex、Claude 都同意才做。我的立場見該待辦說明。

（以下為當日第一批紀錄）**SEO／GEO 審查＋業主四項需求**。
⚠️ 優先事項：**Google 商家的「網站」欄位指向 FB 不是 jjf.tw**（待辦 G1，5 分鐘可改）。HTTPS 憑證已於本日簽發完成，四個 URL 全部 200（G2 已結案）。
本輪完成：垃圾清運相簿改分類、林口／龜山標註、頁尾商家地圖、Google 評論區、JSON-LD 補 address/geo/sameAs。⚠️ 請 Codex 覆審。

（上一輪 Codex）準備接入自有網域 `jjf.tw`：Vite base 改為 `/`，canonical／OG／JSON-LD／sitemap／robots／分享轉址同步改為根網域路徑。
本輪已通過 `pnpm lint`、`pnpm build`、本機 preview 首頁／案例頁／分享轉址驗證；DNS、GitHub Pages custom domain、HTTPS 憑證與 LINE/社群快取仍需完成瀏覽器設定與傳播確認。

---

## 1. 專案現況

| 項目 | 值 |
|---|---|
| 站別 | 潔淨坊清潔工作室（居家／裝潢／重點／特殊清潔） |
| 網址 | https://jjf.tw/ |
| 舊網址 | https://campcool.github.io/0983531549/ |
| 自有網域 | `jjf.tw` 接入中；需 GitHub Pages custom domain + GoDaddy DNS 傳播完成 |
| 技術棧 | React 19.1 + Vite 6.3，pnpm 10.4.1，無 router |
| 部署 | GitHub Actions（`.github/workflows/deploy.yml`）→ push `main` 自動部署 |
| Pages 來源 | 必須維持 `GitHub Actions`，不要改回分支部署 |
| 轉換目標 | **LINE 諮詢／撥號**（服務站，不是訂單站，不要套租賃站的 KPI） |
| **Google 商家** | **已存在且經營良好**：潔淨坊清潔，**4.5 星／31 則評論／387+ 張相片**，最早評論在 6 年前 |
| 商家地址 | 244 新北市林口區仁愛路二段 190 號（座標 25.0740067, 121.3804504） |
| 商家連結 | https://maps.app.goo.gl/m9EWz1xmNiZnvjMw7 |

> ⚠️ **不要再寫「第一優先：建立 Google 商家檔案」**——商家早就有了，而且是這個站目前
> **最強的資產**（31 則真實評論、387 張照片，遠多於網站的 58 張）。該做的是**優化既有商家**，
> 不是建立。最高投報的一項見待辦 G1。

### 頁面結構（Vite 多入口 MPA，非 SPA）

四個 HTML 入口各掛一支 jsx，設定在 `vite.config.js` 的 `rollupOptions.input`：

| 入口 | 進入點 | 用途 |
|---|---|---|
| `index.html` | `src/main.jsx` | 首頁 |
| `cases/index.html` | `src/cases.jsx` | 案場相簿（12 相簿／104 張照片／2 支影片） |
| `cases/manage/index.html` | `src/caseAdmin.jsx` | 內部照片壓縮工具（已 noindex） |
| `share/index.html` | 無 jsx，純轉址頁 | LINE 分享預覽用 |

React runtime 已正確拆成共用 chunk（189 KB／gzip 59.7 KB），四個入口共用，**不需要再做 manualChunks**。

### 分支狀況（2026-09-10 實查）

- `main` — 唯一有效分支，最新狀態以 `git log -1 --oneline` 為準；目前採直推 main 模式。
- `codex/excel-handoff` — **落後 main 27 個 commit、領先 0**。沒有任何獨有內容，是被遺留的空殼。
  **不要以為那裡有未完成的工作**；確認後可直接刪除。
- 此 repo 從未開過 PR（`gh pr list --state all` 為空），目前是**直推 main** 模式。

---

## 2. 內容邊界（動文案前必讀，這是業主的刻意決定，不是待修）

`DESIGN.md` 的 Do's and Don'ts 已明文規定，**任何 AI 不得自行放寬**：

- **不寫死價格**。費用受坪數、髒污程度、工具耗材、交通與時間影響，一律「確認需求後再說明」。
- **不虛構**價格、案例、評論、年資、認證或人物資料。
- **不使用**未授權客戶圖片、未確認的前後對比或未確認的官方品牌素材。
- 照片只用業主實際提供的案場素材。

> **給接手 AI 的提醒**：稽核時「沒有價格、沒有評論」看起來像轉換率的弱點，
> 但那是內容政策。改善轉換要在**不破壞這條邊界**的前提下做——
> 例如不是編一個價格，而是說明「怎麼計價」；不是補評論，而是把既有的
> 58 張實拍照拉成可查證的數字錨點。

### FAQ 與案例頁一致性

已改寫 `src/main.jsx` FAQ 第 3 題：承認案例頁有自家案場實拍相簿，同時維持內容邊界，
不放未確認客戶名稱、評論或成果數字；前後對比只使用已確認可公開的素材。

---

## 3. 關鍵常數（改動前先全域搜尋，多處重複）

| 常數 | 值 | 出現位置 |
|---|---|---|
| LINE ID | `chenli0775` | `main.jsx`、`cases.jsx`、`index.html` JSON-LD |
| LINE URL | `https://line.me/R/ti/p/~chenli0775` | 三支 jsx 各自宣告一次 |
| 電話 | `0983531549` | jsx、JSON-LD、README |
| FB 粉專 | `https://www.facebook.com/share/1GMwVQdp7J/?mibextid=wwXIfr` | `main.jsx`、`cases.jsx` |
| Vite base | `/` | `vite.config.js`；自有網域根目錄部署用 |
| 品牌主色 | `--color-primary: #2f8f8f` | `src/style.css:8` |
| 管理入口 | access code hash | `src/caseAdmin.jsx` — 靜態前端只能降低明文暴露，不能當成真正權限控管 |

資產路徑一律走 `assetPath()`（內含 `import.meta.env.BASE_URL`），**不要寫死 `/0983531549/`**。

---

## 4. 已知陷阱（踩過或實測確認）

**1. ~~CSS 背景圖無法 lazy load~~ — 2026-09-12 已修，但原理要記著。**
`loading="lazy"` **只對 `<img>` 有效**，CSS `background-image` 一律立即載入。
scenario 卡片原本用 `style={{'--scenario-image': url(...)}}`，五張（實測位置在
`top` 1625–2537px，全部在 844px 首屏之下）每次開頁都跟著載，佔首屏 949 KB。
已改成 `.scenario-photo > img[loading=lazy]`，白色漸層移到 `::after`，視覺等價。
**下次要在卡片上放裝飾圖，請一律用 `<img>`，不要回頭用 background-image。**

**2. `share/index.html` 曾硬編碼 Pages 子路徑。**
2026-09-11 已配合 `jjf.tw` 改為 `window.location.replace('/')` 與根目錄 fallback 連結。
若未來又切回子路徑部署，必須同步檢查這兩處與 `vite.config.js` 的 `base`。

**3. `DESIGN.md` 已與實作漂移。** 照著它做會改錯檔案：

| DESIGN.md 指定 | 實際使用 | 狀態 |
|---|---|---|
| `logo-horizontal.png` | `logo-horizontal-transparent.png` | ✅ 2026-09-12 已校正 |
| `favicon.png` | `favicon-transparent.png` | ✅ 2026-09-12 已校正 |
| `og-image.png` | `og-cleaning-area-services-20260910.jpg` | ✅ 2026-09-12 已校正 |
| 大標「潔淨坊／清潔服務」 | 「照片先確認範圍／再安排到府服務」 | ✅ 2026-09-13 已校正 |

上面三個死檔已於 2026-09-12 連同其他死資產一起刪除，DESIGN.md 與 README.md 的指向
也一併改成實作真正在用的檔名。大標與首頁定位已於 2026-09-13 同步為「照片先確認範圍」。

**4. `caseAdmin.jsx` 仍不是正式權限系統。**
目前已移除 `1549` 明文比對，改用 SHA-256 hash 檢查 access code，並補上照片壓縮失敗時的
`try/finally` UI 復原。這只能避免明文密碼直接出現在 bundle；靜態前端仍無真正上傳權限控管。
該工具只做瀏覽器內 canvas 壓縮、不碰後端，所以**不是資料外洩**，但不要把它當成正式後台。

**5. 圖片是這個站唯一的效能問題。**
首屏傳輸 1,563 KB 中有 1,486 KB（95%）是圖片，JS+CSS 合計僅 78 KB。
`public/` 共 40.6 MB，其中 4.63 MB 是完全沒被引用的死資產。**優化請往圖片方向做，不要動打包設定。**

**6. Windows 環境下掃描腳本輸出中文會炸。**
cp950 主控台跑 Python 輸出繁中會 `UnicodeEncodeError`，前面加 `PYTHONIOENCODING=utf-8`。

**7. Pages 子路徑放不了有效的 `robots.txt`；自有根網域才會生效。**
`robots.txt` 依 RFC 9309 **只在 origin 根目錄生效**，子路徑部署時爬蟲只會請求 `https://campcool.github.io/robots.txt`，
不會去讀子路徑的同名檔。實測：

| URL | 狀態 |
|---|---|
| `https://campcool.github.io/robots.txt` | **404**（該根目錄由 `Campcool/campcool.github.io` 決定，該 repo 不存在） |
| `https://campcool.github.io/0983531549/robots.txt` | 200，但**爬蟲不會讀這裡** |

2026-09-11 已把 `public/robots.txt` 改成根網域路徑：`Disallow: /cases/manage/`、`Sitemap: https://jjf.tw/sitemap.xml`。
只有在 `https://jjf.tw/robots.txt` 可公開讀取後，這份檔案才算真正生效；DNS/Pages 尚未傳播完成前不要標成 SEO 已驗收。

替代方案，兩者都有效：
- 管理頁的 `<meta name="robots" content="noindex, nofollow">` 是頁面層級，**照常有效**，管理頁其實沒有外洩風險。
- `sitemap.xml` 放子路徑本身合法，但失去 robots.txt 指向後，只能在 GSC 手動提交。

**8. 改 LINE 色票要連 `.line-contact-card` 一起改。**
`--color-line` 之外，`style.css` 的 `.line-contact-card` 另有一組硬編碼的 rgba 漸層。
只改變數會漏掉這張卡片。2026-09-10 已一併改為 `#017a35` 系。

**9. 案例頁四大分類的張數／相簿數／跳轉目標，一律從 `albums` 計算，不要硬編碼。**
2026-09-10 曾寫死「15／14／13／16 張」，結果與點開後實際看到的張數對不上
（標「重點清潔 14 張」，點進去只有洗地打蠟 5 張），因為 `count` 是分類總和、
`target` 卻只指向單一相簿。現已改為 `featuredCategoryMeta` + 從 `albums` 推算。
**新增或搬動相簿時不需要再改任何數字**；只有業主指定要跳特定相簿時才在 meta 裡寫 `target`。

**12. 相簿做過跨來源重組，`tools/watermark-cases.ps1` 已無法重建 `wood-floor-cleaning`。**
2026-09-11 業主指正後做了跨相簿搬移：
- `floor-adhesive-removal` 原 7 張抽走 01/02（木紋地板）→ 重新編號為 5 張
- `commercial-kitchen` 原 16 張抽走 06/07（木地板）→ 重新編號為 14 張
- `wood-floor-cleaning` 為新相簿，由上述 4 張**跨兩個來源**組成

腳本是「來源資料夾 → 輸出相簿」一對一對應，**做不出跨來源相簿**。
直接重跑會讓被抽走的照片回來、編號錯位，前台出現重複或破圖。
要重跑請先把來源端照片也依新分類整理好。腳本檔頭已加同樣警告。

另外 `commercial-kitchen` 的 10／12／13 三張原本是橫躺的（拍攝時橫向、
且浮水印腳本用 System.Drawing 處理時丟失了 EXIF Orientation），
已用 PIL 順時針旋轉 90° 修正並重存。**若重跑腳本，這三張會變回橫躺。**

**14. OG 圖有兩支產生器，改文案必須兩支一起改。**
- `scripts/generate-og.ps1`：Windows／System.Drawing，需要 `%WINDIR%\Fonts\NotoSansTC-VF.ttf`。業主本機用。
- `scripts/generate-og.py`：跨平台／Pillow，沙盒與 CI 用。字型從 Google Fonts 取 **同一個** Noto Sans TC 家族。

兩支畫的是同一張 `public/og-cleaning-area-services-20260910.jpg`。**只改其中一支，下一個人重跑另一支就會把改動蓋回去。**

移植時踩到的一件事：**GDI+ 的 `DrawString` 預設 StringFormat 會在字串左右各補約 `em/6` 的留白，Pillow 不會**。
不補這段，所有文字會比 PS1 的輸出往左偏 0.17 em（82px 字就是 14px）。這個係數是拿舊圖未改動的元素
（品牌字 82px、副標 44px、slogan 35px、浮水印 24px）逐像素互相關校正出來的，四個字級量到的位移都落在
−0.16 ~ −0.17 em；垂直方向兩者一致、不需要偏移。校正後未改動元素的位移是 0–3px。

另外兩支的 JPEG 編碼器不同，檔案大小會有差（PY 用 4:4:4 保住彩色文字邊緣，264 KB；GDI+ 預設會小一些）。
這張圖只有爬蟲與 LINE／FB 會抓，不影響訪客首屏，不必為了大小犧牲文字銳利度。

**13. 有色底上的白色半透明疊層會相乘，只改底色救不了對比。**
2026-09-12 稽核發現「服務流程／LINE 詢問資料」整段白字都不到 WCAG AA
（最低 `.step-list small` 只有 **2.57:1**）。第一次只把 `.split-section` 的漸層
亮端從 `#2f8f8f` 壓到 `#1d6b6b`，實測只從 2.57 升到 3.41 —— 因為上面還疊了兩層白：

| 層 | 白色疊層 | 淨值 |
|---|---|---|
| `.split-section` | 漸層底色 | — |
| `.process-panel` / `.note-panel` | `linear-gradient(.12,.06)` + `rgba(.08)` | 約 .19 |
| `.step-list li` | `linear-gradient(.14,.07)` + `rgba(.08)` | 約 .19 |

三層相加後實際渲染出來的底色是 `rgb(99,141,148)`（亮度 .238），**純白字在其上
最高只有 3.64:1**，所以那塊底色上任何字色都過不了 AA。最後是底色壓到 `#1a6060`
**加上**兩層白各減半（`.06/.03`+`.03`、`.07/.035`+`.035`）才到 5.2–5.7。

**教訓**：在有色底上量對比要量「實際渲染出來的像素」，不要只看 CSS 裡寫的底色值；
用透明度做視覺層級在有色底上特別危險，層級請交給字級與字重。

**11. 查資產是否還被引用時，一定要掃 `tools/` 與 `scripts/`，不能只掃前台原始碼。**
2026-09-10 我刪 `cases/parking-floor-cleaning/` 前只掃了
`src/ cases/ index.html share/ DESIGN.md README.md`，**漏掉 `tools/`**，
結果 `tools/watermark-cases.ps1` 裡的 mapping 仍指向該 slug，
重跑浮水印腳本會把已刪的相簿重新產出來（由 Codex 覆審抓到）。
**正確作法**：`grep -rn "<關鍵字>" . --exclude-dir=.git --exclude-dir=node_modules --exclude-dir=dist`。
`scripts/generate-og.ps1` 同理，也會引用圖片路徑。

**10. `grid-area` 只在父容器是 grid 時生效——跨 commit 的組合式 bug 要查完整歷史。**
`.header-action { grid-area: actions }` 早在 `af35cda` 就寫下，但當時父層是 flex，屬於無效宣告、
沒人發現。直到 `1188538` 把 `.header-actions` 改成 `display: grid`，這行沉睡的宣告突然生效，
三顆聯絡按鈕全部擠進同一格，畫面上只看得到最後一顆（粉專）。
**教訓**：症狀出現的 commit 不一定是問題的來源。只看單一 commit 的 diff 找不到這種 bug，
要用 `git log -S'<關鍵字>'` 追出宣告的完整生命週期。已於 `e9fd7d4` 移除該規則。

**16. 案例卡縮圖是另外產生的檔案，換相簿第一張照片時要重產。**
2026-09-29 起卡片用 `thumbOf(album.photos[0])`，也就是 `<slug>-01-thumb.jpg`（720×450、16:10 置中裁切、q78）。
新增相簿、或 `-01.jpg` 換了照片，必須重產縮圖，否則卡片破圖或顯示舊照片。`-thumb.jpg` 不算死資產（由程式組字串引用，
grep 檔名找不到），掃描死資產時不要刪。產生方式（sharp）：
`sharp(src).resize(720, 450, { fit: 'cover', position: 'centre' }).jpeg({ quality: 78, mozjpeg: true })`。

**15. 拼圖照片使用 `height:auto` 時，lazy image 必須先有可觀察高度。**
2026-09-28 線上複驗發現，`.album-photo-card.is-composite img { height:auto }` 會讓尚未取得
intrinsic size 的 `loading="lazy"` 圖片高度為 0；IntersectionObserver 永遠看不到圖片，11 張一般居家
照片全數停在 `complete=false / naturalWidth=0 / clientHeight=0`，畫面只剩 caption。
修正是在同一規則加 `aspect-ratio: auto 3 / 4`：圖片未載入前用 3:4 預留高度，載入後 `auto`
切回每張實際比例；`object-fit:contain` 仍保證拼圖不裁切。日後不要單獨把 lazy image 改成 `height:auto`。

---

## 5. 待辦清單（2026-09-10 稽核產出，依施工順序排列）

狀態圖例：`⬜ 未開始` / `🟨 進行中` / `✅ 已完成並實測`

2026-09-29 晚 Codex 完成 H2 覆審與 header 共用化，`bba5150` 已部署並由業主確認；H 系列結案。
2026-10-03 Codex 新增 Google Ads 圖片素材：5 橫式、5 方形、2 直式、2 Logo；另附 manifest、contact sheet 與可重跑 Pillow 腳本。素材只取既有實拍照，排除 LINE 拼貼、縮圖、原圖疊字與可見浮水印。
2026-10-05 Codex 依業主新指示新增 AI 生成情境素材：5 種服務各有 1.91:1、1:1、4:5，共 15 張；輸出、manifest、contact sheet 與母圖皆獨立放在 `images-ai-generated/`、`generated-masters/`，不得與實拍批次混稱。
2026-09-29 晚 Claude 移除一般居家清潔重複冰箱照（105→104 張）。
2026-09-29 晚 Claude 完成 H3、H7–H16（H16 當時為 105／12，移除重複照後現為 104／12）；交由 Codex 完成 H2 覆審。
2026-09-29 Claude 唯讀審查 `5bc9b74`：維持上線；新增 H9–H14（P2×3、P3×3）與業主需求 H15（水垢處理併入一般居家清潔）。
2026-09-29 Codex 重設案例頁標籤與卡片視覺；移除前台數量、完成 H1／H5／H6，並通過 375／768／1280 與實際篩選互動驗證。
2026-09-28 深夜 Claude 修正首頁／案例頁 header 三處不一致；新增 H1–H4，H1–H3 排給 Codex 併入 E2 一起做（見檔案開頭清單）。
2026-09-28 Codex 將案例頁重構成複合標籤速查；可依情境、空間、需求交叉篩選，375／768／1280 本機驗證通過，待 Claude 覆審。
2026-09-28 Codex 覆審並修正拼圖 lazy-load 零高度；38 張部署照片已壓縮 20.43→9.45 MB，lint/build 通過。
2026-09-28 業主提供 38 張實拍照片，新增「一般居家清潔」（11 張）與「退租入住清潔」（27 張）兩個相簿；C6、E1 部分結案。
2026-09-24 業主需求：OG 服務地區改五個地區、新增「退租入住」情境卡，皆已完成；新增 C6（退租入住相簿待業主給照片）。
2026-09-12 上架前稽核：B1 已完成；C3 完成三項之二（死資產、DESIGN.md、CI lint），只剩圖片轉 WebP。
新增 B6（影片壓縮）、B7（scenario／hero 專用小圖）、C4（粉專網址待業主確認）、C5（手機導覽觸控高度）。
本輪 2026-09-13 已完成 B3/B4 的首頁信任層級與首屏位階調整，等待 Claude 覆審與真機視覺確認。

| # | 優先 | 項目 | 位置 | 預估 | 狀態 |
|---|---|---|---|---|---|
| A1 | 🔴 阻斷 | 改寫 FAQ 第 3 題，讓它與案例頁現況一致 | `src/main.jsx:241` | 10 分 | ✅ 已複驗 |
| A2 | 🔴 阻斷 | LINE 按鈕改 `#017A35`、hover `#006B2E`（原白字對比僅 2.26:1，AA 不過） | `src/style.css:13`（已從 handoff-fixes.css 併回） | 10 分 | ✅ 已複驗 |
| A3 | 🔴 阻斷 | 修 `c2f7fbd` 兩個無障礙迴歸：`aria-controls` 指向不存在元素（9/9）、`aria-hidden` 藏掉分類卡與索引卡張數 | `src/cases.jsx`、`style.css` | 30 分 | ✅ **待 Codex 覆審** |
| B1 | 🟠 高 | scenario 背景圖改 `<img loading="lazy">`＋`object-fit:cover` | `src/main.jsx:426`、`style.css:967` | 1 小時 | ✅ **2026-09-12 完成並實測**：首屏 1,975→1,177 KB |
| B2 | 🔴 阻斷 | 自有網域根目錄接上後，確認 `robots.txt`／`sitemap.xml` 可公開讀取，並到 GSC 手動提交 sitemap | GitHub Pages／GoDaddy／GSC 後台 | 30–60 分 | 🟨 **接入中，GSC 需業主帳號** |
| B5 | 🟢 中 | 案例頁 header 相簿導覽（9 膠囊 3×3）**已移除**，導覽職責交給下方「案場相簿索引」 | `src/cases.jsx`、`style.css` | 1 小時 | ✅ **待 Codex 覆審** |
| B3 | 🟠 高 | 加數字錨點帶（67 張實拍／11 個相簿／4 大類／31 則 Google 評論）＋風險逆轉三句 | `src/main.jsx` | 2 小時 | ✅ **2026-09-13 完成，待 Claude 覆審** |
| B4 | 🟠 高 | 首屏位階對調：品牌名退到副標，價值主張升為主標；補照片確認、非固定價格、實拍素材承諾 | `src/style.css`、`main.jsx` | 3 小時 | ✅ **2026-09-13 完成，待 Claude 覆審** |
| C1 | 🟠 高 | `handleFiles` 補 `try/finally`；移除硬編碼密碼 | `src/caseAdmin.jsx:88`、`:6` | 30 分 | ✅ |
| C2 | 🟡 待決策 | LINE 標誌換官方素材（現為自繪，違反自家 DESIGN.md） | `public/brand/icon-line.svg` | 待業主 | ⬜ |
| C3 | 🟢 中 | ~~刪死資產~~、~~同步 DESIGN.md~~、~~CI 加 `pnpm lint`~~ 已完成；**只剩圖片轉 WebP** | 多處 | 2 小時 | 🟨 **部分完成** |
| B6 | 🟢 中 | 兩支影片未壓縮：`commercial-kitchen-video.mp4` **14.7 MB**（全站最大單一檔）、`paint-cleaning-video.mp4` **3.8 MB**。720p H.264 CRF 26 通常可到 2–3 MB。`<video preload="metadata">` 所以只在客人按播放時才整支下載，不影響開相簿速度，但手機網路播放會卡。沙盒無 ffmpeg，**業主在本機做** | `public/cases/commercial-kitchen/`、`public/cases/paint-cleaning/` | 30 分 | ⬜ **業主本機** |
| B7 | 🟢 中 | hero 與 scenario 另外輸出手機用小圖。現在首屏仍有 `garbage-clearance-01.jpg`(376KB)＋`site-cleaning-hero.jpg`(291KB)＋`room-after-work`(183KB)＝850 KB，這三張是 1108×1477 原圖卻只渲染成 ~350px 寬（scenario 還只有 34% 不透明度）。輸出 5+1 張 ~720px 寬的衍生圖可再省約 600 KB | `public/cases/` | 1 小時 | ⬜ |
| C4 | 🟡 **待業主確認** | 粉專網址不一致：站上三個入口用 `facebook.com/share/1GMwVQdp7J/?mibextid=wwXIfr`（帶追蹤參數的分享短連結），首頁 JSON-LD 的 `sameAs` 用 `facebook.com/chenli0775/`。`sameAs` 是給搜尋引擎做實體消歧用的，指到兩個不同 URL 會削弱訊號。**請業主到 FB 後台確認現行正式網址**，再把兩處一起改 | `src/main.jsx:40`、`src/cases.jsx:24`、`index.html:40` | 10 分 | ⬜ |
| C5 | 🟢 中 | 手機版 6 顆導覽膠囊高 32px，低於 Google 行動友善建議的 48px（WCAG 2.5.8 的 24px 已通過）。**本輪刻意不改**：header 是固定 96px、膠囊排成 3×2，拉到 44px 會撐破 header，要連 `--header-height` 與依賴它的 `[id]{scroll-margin-top}` 一起調，風險不小（陷阱 9、10 都是 header 改動出的事），不適合上架前做 | `src/style.css:169` | 1 小時 | ⬜ |
| **G1** | 🔴 **最高投報** | **Google 商家的「網站」欄位目前指向 `facebook.com/chenli0775/`，不是 `jjf.tw`**。商家是本地搜尋最大流量來源，等於把流量送給 FB。改一個欄位即可 | Google 商家後台 | 5 分 | ⬜ **需業主帳號** |
| G2 | 🔴 阻斷 | HTTPS 憑證 — **2026-09-11 已簽發完成並自動生效** | GitHub Pages | — | ✅ 已驗證 |
| G3 | 🟠 高 | `public/CNAME` 已建立並確認進入 `dist` 產物 | `public/CNAME` | 10 分 | ✅ 已完成 |
| G4 | 🟠 高 | **全站是 CSR，爬蟲看到的 `<body>` 是 0 字**。Googlebot 會渲染 JS，但多數 AI 爬蟲（GPTBot／ClaudeBot／PerplexityBot）不執行 JS，等於整站內容對 AI 搜尋不可見 | 需架構決策 | 需討論 | 🟡 **業主指定三方決議**：業主、Codex、Claude 三方都同意才做 |
| G5 | 🟢 中 | 案例頁已補 `BreadcrumbList` ＋ `ImageGallery`（11 個相簿、代表圖與張數），並以 `about` 指回首頁的 business `@id` | `cases/index.html` | 30 分 | ✅ 已完成 |
| **G6** | 🔴 **需業主帳號** | **填入 GA4 Measurement ID 才會開始收數據**。埋點已完成，`src/analytics.js` 的 `GA_MEASUREMENT_ID` 目前是空字串（安全 no-op）。到 GA 建資源拿到 `G-XXXXXXXXXX` 後填入、推 main 即生效 | `src/analytics.js` | 5 分 | ⬜ |
| C6 | 🟡 **已開相簿** | 2026-09-28 業主提供 27 張退租入住清潔照片，新增 `move-in-cleaning` 相簿（重點清潔）；`public/cases/move-in-cleaning/` 共 27 張。照片已縮至最長邊 1600px、JPEG quality 82；尚未過浮水印腳本。 | `src/cases.jsx`、`public/cases/move-in-cleaning/` | — | ✅ **2026-09-28 完成並覆審** |
| E1 | 🟡 **部分完成** | `general-home-cleaning` 現為 14 張、`move-in-cleaning` 為 27 張，首頁「一般清潔」在案例頁已有對應。裝潢清潔 vs 裝潢細清名稱差異仍存在，待業主決定是否更名 | `src/main.jsx`、`src/cases.jsx` | 需確認 | 🟨 **部分完成** |
| H1 | 🟢 中 | 案例頁原「← 回首頁」字級修正；後由共用 header 取代 | `src/SiteHeader.jsx`、`src/style.css` | 15 分 | ✅ **2026-09-29 完成並由業主確認** |
| H2 | 🟢 中 | 覆審 header 修正並統一首頁／案例頁最上方導覽列 | `src/SiteHeader.jsx`、`src/main.jsx`、`src/cases.jsx`、`src/style.css` | 15 分 | ✅ **2026-09-29 覆審結案；`bba5150` 已部署** |
| H3 | 🟢 中 | 重新量測 820–1279px 首頁底部 dock 聯絡鈕 | `src/style.css` | 15 分 | ✅ **主要斷點通過；1279 分數像素限制見第 6 節（六）** |
| H4 | 🟢 中 | 覆審 E2 標籤語意 | `src/cases.jsx` | 30 分 | ✅ **2026-09-28 Claude 覆審完成** |
| H5 | 🟠 高 | `grease-kitchen` 已補「居家」「商用」，住家與店面篩選都可找到 | `src/cases.jsx:96` | 5 分 | ✅ **2026-09-29 完成並實測** |
| H6 | 🟢 低 | 標籤與標題已統一使用「重油汙」 | `src/cases.jsx` | 5 分 | ✅ **2026-09-29 完成** |
| H8 | 🟢 中 | 23 張最長邊 >1600px 照片壓縮：7.31→4.22 MB | `public/cases/` | 30 分 | ✅ **2026-09-29 Claude 完成** |
| H9 | 🟠 高 | 案例卡改用 720×450 縮圖：375px 捲完列表圖片 3.76→0.72 MB | `src/cases.jsx` | 1 小時 | ✅ **2026-09-29 Claude 完成** |
| H10 | 🟠 高 | 分類色章白字對比 4.41→5.46:1 | `src/style.css` | 5 分 | ✅ **2026-09-29 Claude 完成** |
| H11 | 🟠 高 | `#album-finder` 深連結補捲動 | `src/cases.jsx` | 15 分 | ✅ **2026-09-29 Claude 完成** |
| H12 | 🟢 低 | 移除標籤容器 `aria-label` | `src/cases.jsx` | 5 分 | ✅ **2026-09-29 Claude 完成** |
| H13 | 🟢 低 | 無結果畫面補 LINE 按鈕 | `src/cases.jsx` | 10 分 | ✅ **2026-09-29 Claude 完成** |
| H14 | 🟢 低 | 手機 h2 不再大於 h1 | `src/style.css` | 5 分 | ✅ **2026-09-29 Claude 完成** |
| H15 | 🟠 高 | 「重水地區水垢處理」併入「一般居家清潔」 | 多檔 | 1 小時 | ✅ **2026-09-29 Claude 完成** |
| H7 | 🟢 中 | 「洗地打蠟」業主 2026-09-29 決定標「居家」＋「商用」 | `src/cases.jsx` | 5 分 | ✅ **2026-09-29 完成** |
| H16 | 🟢 中 | 首頁數字錨點現為 104 張／12 個相簿（業主決定更新、不移除）；`dt` 加 `46cqi` 上限修正溢出 | `src/main.jsx`、`src/style.css` | 15 分 | ✅ **2026-09-29 完成並覆審** |
| I1 | 🟢 中 | Google Ads 實拍圖片素材：5 橫式、5 方形、2 直式、方形／橫式 Logo 各 1；含來源清單、處理紀錄與檢查總覽 | `ads/google-ads/` | 1 小時 | ✅ **2026-10-03 完成並實測** |
| I2 | 🟢 中 | Google Ads AI 生成情境素材：櫥櫃、商業廚房、洗地打蠟、裝潢後細清、浴室黴垢，共 15 張；來源與實拍批次分開標記 | `ads/google-ads/images-ai-generated/`、`generated-masters/` | 1 小時 | ✅ **2026-10-05 完成並實測；上傳時建議啟用 AI 標籤** |
| E2 | 🟢 中 | 案例頁以 `tags` 建立三組複合速查；三組採一致白底與三色上緣識別線，選項為低圓角分段按鈕。分類用深色方角色章、標籤用淺色圓膠囊。前台不顯示案件／照片／影片數字，只保留全部案例、已選標籤與取消全部 | `src/cases.jsx`、`src/style.css`、`DESIGN.md` | — | ✅ **2026-09-29 重設並完成互動實測** |
| D1 | 🟡 待討論 | 設計回流機制（定期清潔提醒、老客推薦）— 五段檢查第 5 段完全空白 | — | 需先討論 | ⬜ |

### 待辦細節（施工時展開看）

**A1 完成說明**（守住內容邊界，同時說實話）：
FAQ 已改成「案例頁已整理自家案場實拍相簿」，並明確不放未確認客戶名稱、評論或成果數字。

**A2 完成說明**（白字對比實測）：
`src/style.css` 已覆寫 `--color-line: #017A35`、`--color-line-strong: #006B2E`；`handoff-fixes.css` 已併回並刪除，不要再新增獨立補丁 CSS。主 LINE CTA 白字對比達 AA。

**B2 注意**：依可信度設計規則，**自家網站不得對自家服務加 `Review` 或 `AggregateRating` 結構化資料**
（self-serving markup，Google 會取消 rich result 甚至人工處罰）。要放數字請標「服務件數」。
目前 JSON-LD 未誤用這兩者，維持現狀即可。`public/robots.txt` 與 `public/sitemap.xml` 已新增；
Google Search Console 送審仍需有權限的人手動處理。

**C3 死資產清單**（2026-09-10 重新盤點，分母 `public/` 共 40.77 MB，死資產 **4.38 MB / 11%**）：

| 檔案 | 大小 | 說明 |
|---|---|---|
| `cases/rental-clearance/` 5 張 | 1.90 MB | 是 `case-20260909/` 的逐位元組副本 |
| `og-line-square-20260909.png` | 985 KB | ✅ 2026-09-12 已刪 |
| `og-image-20260909-service-area.png` | 623 KB | ✅ 已刪（與下兩者 md5 完全相同） |
| `og-image-20260909-line-card.png` | 623 KB | ✅ 已刪 |
| `og-image.png` | 623 KB | ✅ 已刪（只有 DESIGN.md／README.md 指到，已一併校正） |
| `brand/logo-mark.png` | 300 KB | ✅ 已刪 |
| `brand/logo-horizontal.png` | 325 KB | ✅ 已刪（陷阱 3 的死檔） |
| `brand/favicon.png` | 298 KB | ✅ 已刪（陷阱 3 的死檔） |

`public/robots.txt` 與 `sitemap.xml` **不是**死資產（給爬蟲用，本來就不會被 HTML 引用），
掃描腳本會誤報，不要刪。

已清除：`cases/parking-floor-cleaning/` 5 張（1.60 MB），2026-09-10 刪除。
`cases/rental-clearance/` 與 `case-20260909/` 也早已不存在（舊清單未同步，2026-09-12 校正）。
**2026-09-12 共刪 3.66 MB**，刪除前已照陷阱 11 全庫掃過（含 `tools/`、`scripts/`），
`scripts/generate-og.ps1` 用的是 `logo-horizontal-transparent.png`，不受影響。

---

## 5.5 事件追蹤（GA4）

埋點已完成，**但還沒開始收數據**——`src/analytics.js` 的 `GA_MEASUREMENT_ID` 目前是空字串。

**怎麼啟用**：到 Google Analytics 建立 GA4 資源，取得 Measurement ID（格式 `G-XXXXXXXXXX`），
填進 `src/analytics.js` 最上方那個常數，推 main 就生效。
Measurement ID 會出現在前端原始碼裡，這是 GA4 的正常設計，**不是機密**，不需要放 GitHub Secret。

**沒填 ID 時的行為**：不載入任何外部資源、不發任何請求、所有追蹤呼叫都是安全的 no-op。

**怎麼驗證埋點有沒有在跑**（不需要 GA）：開瀏覽器 Console 輸入 `window.__trackLog`，
會看到目前這次瀏覽記錄到的所有事件。這個 log 無論有沒有設定 GA 都會運作，最多保留 200 筆。

**收集的事件**：

| 事件 | 參數 | 說明 |
|---|---|---|
| `contact_click` | `method`（line／phone／facebook）、`area` | 所有聯絡按鈕點擊 |
| `album_open` | `album`（slug）、`source`（category_card／index_card／drawer） | 相簿開啟，可看出客戶對哪類清潔有興趣 |
| `nav_click` | `target`、`area` | 站內導覽、前往案例頁、Google 地圖 |

`area` 取自最近祖先的 `data-track-area`，目前標了 hero／dock／inquiry／process／business／reviews／hero_line_hint。

**實作方式**：用**一個事件委派**接管全站 `<a>` 的點擊，不必在每個連結掛 onClick——
新增聯絡按鈕時自動就會被追蹤，不會漏。相簿開闔因為是 `<button>`，另外明確呼叫 `trackAlbum`。

⚠️ 已明確追蹤的元素要加 `data-track-skip`，否則同一次點擊會同時產生 `album_open` 與
`nav_click`，數據重複計算（相簿索引卡就踩過這個坑，已修）。

---

## 6. 進度紀錄（倒序）

### 2026-10-05 Codex 建立 Google Ads AI 生成情境素材第二批

**業主新指示**：可以考慮以生成方式製作素材，主要用於 Google Ads。這項新授權只適用於本批次；2026-10-03 的第一批仍維持「網站實拍、非 AI」屬性。

**改動**：
- 以生成式圖片工具建立 5 張寫實服務情境母圖：櫥櫃細清、商業廚房洗地、洗地打蠟、裝潢後細清、浴室黴垢處理。
- 新增 `ads/google-ads/build-generated-ad-images.py`，由每張母圖輸出 1200×628、1200×1200、960×1200 三種比例，共 15 張。
- 母圖存放在 `generated-masters/`，上傳素材存放在 `images-ai-generated/`，並以 `ai-` 檔名前綴及 `manifest-ai-generated.csv` 明確標示 AI 來源。
- 所有場景均限制為成人、不可辨識臉孔、無品牌制服、無文字、無 Logo、無浮水印、無拼貼、無前後對比與無誇張成效。

**Google Ads 規格核對**：依 2026-10-05 查閱的 Google 官方文件，搜尋廣告圖片必要方形 1:1、建議橫式 1.91:1，建議尺寸分別為 1200×1200 與 1200×628、檔案上限 5120 KB、重要內容置於中央 80%；生成式內容仍適用一般廣告政策。Google 也提供 AI content label setting，本批上傳時建議啟用。

**驗證**：15 張皆為 JPEG、尺寸與比例符合規格、單檔低於 5 MB；contact sheet 逐張目視確認構圖可辨識、無疊字、Logo、邊框、拼貼或可辨識臉孔；`public/`、`src/` 無異動。

**本輪明確未驗**：尚未實際上傳 Google Ads，因此未取得平台審核結果；生成情境並非實際案場或真實員工，不應搭配「本案實績」「完工成果」等敘述。

### 2026-10-03 Codex 建立 Google Ads 實拍圖片與 Logo 素材

**業主需求**：搜尋廣告圖片只使用網站既有實拍照；輸出橫式、方形與直式比例，加上兩種 Logo；不得生成新畫面、疊字或使用 LINE 拼貼。

**改動**：
- 新增 `ads/google-ads/build-ad-images.py`，以 Pillow 做可重跑的裁切、縮放、輕度曝光／對比／飽和度調整與指定臉部模糊；不做生成、補畫、物件移除或成果美化。
- `ads/google-ads/images/` 輸出 5 張 1.91:1、5 張 1:1、2 張 4:5 JPEG，以及 1:1／4:1 白底 Logo PNG 各 1。
- 照片涵蓋商業廚房、洗地打蠟、地板殘膠、木地板清潔與雨遮清潔共 5 種服務；來源排除 `general-home-cleaning/`、`move-in-cleaning/`、`*-thumb.jpg`、原圖疊字及無法藉裁切排除的浮水印。
- 新增 `manifest.csv` 記錄每張來源、比例、尺寸、放大倍率、服務與調整；新增 `contact-sheet.jpg` 供業主總覽，該總覽不是廣告上傳素材。

**驗證**：14 個上傳素材皆為指定 JPEG／PNG；尺寸與比例符合規格，最大放大倍率不超過 1.15，單檔皆小於 5 MB；輸出目視確認無疊字、邊框、浮水印與拼貼，唯一可辨識臉部已局部模糊；`public/`、`src/` 無異動。

**本輪明確未驗**：尚未實際上傳 Google Ads，因此無法確認平台最終審核結果；調色與裁切已目視檢查，但仍建議業主以 contact sheet 做最後品牌偏好確認。

### 2026-09-29（六）Codex 完成 H2 覆審並統一首頁／案例頁最上方導覽列 ✅ 結案

**業主需求**：首頁與案例頁的最上方 bar 必須一致，避免消費者進入案例頁後感覺像換了網站。

**改動**：
- 新增 `src/SiteHeader.jsx`，首頁與案例頁共用同一份 logo、六個導覽項目及 LINE／電話／粉專按鈕結構。
- 案例頁的「案例相簿」連到 `#album-finder` 並標示 `aria-current="page"`；其他五個導覽連回首頁相對區塊。
- 移除案例頁原有 64／84px 專屬 header、logo 與聯絡按鈕尺寸覆寫，兩頁全面沿用相同 responsive header 規則。
- 案例頁補上 skip link 與 `main#main-content`，維持與首頁一致的鍵盤導覽入口。

**驗證**：`pnpm lint`／`pnpm build` 通過；production preview 在 375／820／1280／1440 實測兩頁 header 高度、logo 尺寸、導覽項目與聯絡按鈕顯示規則一致，皆無水平溢出；案例頁「需求情境」可正確回到首頁 `#needs`。

**H2 覆審結論**：維持上線，不需回退。`652060a...23426ed` 的相簿合併、104 張／12 相簿、縮圖與壓縮、標籤篩選、深連結、無障礙名稱、首頁數字及原 header 修正均完成實測；未發現阻擋上線問題。業主後續要求兩頁 header 完全一致，已以上述共用元件完成。

**部署與業主驗收**：commit `bba5150` 已推送 `main`；GitHub Pages run `36533094857` 成功。正式站 `https://jjf.tw/` 與 `/cases/` 已載入共用 header，業主回覆「完美」並要求填寫交接文件結案。

**非阻斷後續**：首頁 820–1279px 的固定聯絡 dock 在部分視窗高度會遮住第四個數字磚；1279px 分數像素 viewport 可能同時命中不到 `max-width:1279px` 與 `min-width:1280px`。兩項均未影響本次 header 一致性驗收，若日後調整首頁首屏再一併處理。

**本輪明確未驗**：實體 iOS／Android、Safari／Firefox、LINE 內建瀏覽器與完整螢幕閱讀器走讀；本輪使用 Chromium production preview 與正式站驗證。

### 2026-09-29（五）Claude 移除一般居家清潔重複的冰箱照 ⚠️ 請 Codex 覆審

**業主回報**：一般清潔裡冰箱照片重複。

**查證**：`general-home-cleaning-04.jpg` 與 `-05.jpg` 為同一檔案（md5 `023b8f79…` 相同，1200×1600）。另以 32×32 灰階差異全站兩兩比對 105 張，
除這組為 0 外，最接近的一組差異 19.4（不同照片），**全站沒有其他重複**。

**改動**：
- `git rm` `general-home-cleaning-05.jpg`；`06..15` 依序 `git mv` 為 `05..14`（`generatedPhotos` 需連號）。縮圖 `-01-thumb.jpg` 不受影響。
- `src/cases.jsx`：張數 15→14，註解記錄原因。原水垢 4 張現為 **11..14**。
- `src/main.jsx`：「局部加強需求」圖改指 `general-home-cleaning-11.jpg`（仍是原 `scale-removal-01`）；首頁數字 105→**104** 張。
- `cases/index.html`：JSON-LD 一般居家 15→14 張、總數 105→104、同步註解。
- `tools/watermark-cases.ps1`：註解改為水垢照在 11..14、重跑時從 11 起編號。

**驗證**：`pnpm lint`／`pnpm build` 通過；`cases.jsx` 張數加總 104；375px 開 `#general-home-cleaning` 捲完 14 張全載入、14 個不同檔名；
首頁「局部加強需求」圖片載入、數字磚為 104／12／4／31；無 HTTP 4xx／Console error（Google 地圖為沙盒代理擋掉）。

**注意**：本節之前的紀錄（（三）（四））寫的「一般居家 15 張」「12..15」「105 張」為當時狀態，現況以本節為準。

### 2026-09-29（四）Claude H16：首頁數字錨點更新為 105 張／12 個相簿 ⚠️ 請 Codex 覆審

**業主決定**：首頁數字錨點更新為正確數字（不比照案例頁移除）。

**改動**：
- `src/main.jsx` `proofMetrics`：67→**105** 張實拍照片、11→**12** 個案場相簿（依 `cases.jsx` 的 12 個 `generatedPhotos` 張數加總 = 105 核對）。加註：首頁與案例頁是不同 Vite 入口，無法共用 `albums`，相簿增減時兩邊要一起改。
- `src/style.css` `.hero-proof-list`：「105」變三位數後溢出磚外（375 貼邊、882 被切）。原因是 `dt` 用 `clamp(34px, 10vw, 58px)` 只看視窗寬，
  而 820–1279px 首屏雙欄時磚很窄，**連原本兩位數在 882px 都已溢出**。修法：磚加 `container-type: inline-size`，
  `dt` 改 `min(clamp(34px, 10vw, 58px), 46cqi)`；保留原 `clamp` 那行作為不支援 `cqi` 瀏覽器的 fallback。

**驗證**（production preview，Chromium）：320／375／768／820／882／1024／1279／1280／1440 四塊磚內所有文字皆未超出磚框；
`dt` 字級依序 25.3／31.5／57.0／23.7／29.6／40.1／52.3／52.3／57.0px；lint／build 通過；首頁 Console 除沙盒擋掉的 Google 地圖外無錯誤。

**觀察（改版前既有，未處理）**：820–900px 左右磚寬僅約 60px，`dd` 說明文字換成兩行、數字約 24px；同寬度下右下浮動 LINE 鈕會暫時蓋住第四塊磚。
若要改善需調整首屏雙欄比例，屬版面決策，請 Codex 評估。

### 2026-09-29（三）Claude 依審查結果實作 H3、H7–H15 ⚠️ 請 Codex 覆審（H2 一併）

業主指示「能先做的就先改」，H7 決定「居家＋商用」都標，H15 確認為合併相簿。

**改動**：

| # | 檔案 | 內容 |
|---|---|---|
| H15 | `public/cases/` | `git mv` `scale-removal/scale-removal-01..04.jpg` → `general-home-cleaning/general-home-cleaning-12..15.jpg`，刪空資料夾 |
| H15 | `src/cases.jsx` | 刪 `scale-removal` 相簿；一般居家 11→15 張、`tags` 加「水垢」；新增 `albumAliases`，`#scale-removal` → `general-home-cleaning` |
| H15 | `src/main.jsx` | 「局部加強需求」圖改指 `general-home-cleaning-12.jpg`（同一張）；重點清潔 `items` 移除「重水地區水垢處理」、`copy` 移除「水垢」 |
| H15 | `cases/index.html` | JSON-LD 刪 `#scale-removal`（`hasPart` 12 筆，JSON 可解析）；一般居家描述 11→15 張；總述 13→12 個相簿；同步註解日期 |
| H15 | `tools/watermark-cases.ps1` | 移除 `scale-removal` mapping，改為註解說明（陷阱 11、12） |
| H7 | `src/cases.jsx` | `floor-waxing` 的 `tags` 補「居家」 |
| H8 | `public/cases/` | 23 張 >1600px 以 sharp mozjpeg 縮至 1600px、q82（7.31→4.22 MB）；事前確認 105 張 EXIF orientation 皆為 1 |
| H9 | `src/cases.jsx`、`public/cases/*/` | 新增 `thumbOf()`；12 張 `-01-thumb.jpg`（720×450，共 0.55 MB）；`<img>` 補 `width/height`。見陷阱 16 |
| H10 | `src/style.css` | `.album-index-category` 背景 88%→70% |
| H11 | `src/cases.jsx` | 掛載時 hash 為 `album-finder` 也補捲動；抽出 `getHash()` |
| H12 | `src/cases.jsx` | 移除 `.album-index-tags`、`.album-drawer-tags` 的 `aria-label` |
| H13 | `src/cases.jsx`、`src/style.css` | 無結果畫面加 LINE 按鈕，新增 `.case-filter-empty-actions` |
| H14 | `src/style.css` | `.album-index-heading h2` 改 `clamp(30px, 5vw, 58px)` |

**驗證**（`pnpm build` 後 `pnpm preview`，Playwright Chromium）：

- `pnpm lint` exit 0；`pnpm build` 成功；`git diff --check` 通過。
- 375／768／882／1280／1440：水平溢出 0；12 張卡片；篩選按鈕最小 44px；卡片標籤一致 96／96／113／108／126×32；h2 < h1（30<34、38.4<42、44.1<70.56、58<76、58<76）。
- `#album-finder`：五個寬度皆捲到位，標題 top 144／144／164／202／202，header 底 64／64／84／84／84。
- 流量（375）：首載 0.52 MB；捲完卡片列表圖片 13 張 0.72 MB（縮圖 12 張 0.55 MB），改前 3.76 MB；12 張縮圖皆載入且 naturalWidth 720。
- 篩選：居家＋地板 → 木地板清潔、洗地打蠟、一般居家清潔；衛浴＋水垢、居家＋衛浴＋水垢 → 一般居家清潔；
  廚房＋水垢**現在會找到一般居家清潔**（合併後正確）；商用＋水垢 → 無結果，LINE 按鈕 50px、連到 `line.me/R/ti/p/~chenli0775`，「查看全部案例」回到 12 個。
- 色章白字對比 5.46:1。卡片無障礙名稱：「重點清潔 洗地打蠟 居家 商用 地板 洗地打蠟 查看現場照片」。
- `/cases/#scale-removal`（375）：一般居家清潔展開，15 張；捲完 15 張全載入、無零高度。第 13 張（原水垢照）以 contain 完整顯示。
- 首頁：「局部加強需求」圖片 `general-home-cleaning-12.jpg` 正常載入；全頁文字已無「重水地區水垢處理」。
- H3：819／820／1024／1279 dock 顯示 LINE／電話／粉專（48px）且 header 聯絡鈕收起；1280 反之；皆無溢出。
- Console：案例頁五寬度 × 四種 hash，warning／error／HTTP≥400 皆 0。首頁 Google 地圖 iframe 在沙盒被代理擋（非程式問題）。

**本輪明確未驗**：正式站 `jjf.tw`（沙盒連不到）；iOS／Android／LINE 內建瀏覽器；螢幕閱讀器實際走讀；
H8 壓縮後照片只抽看 1 張（`general-home-cleaning-13`）畫質，其餘未逐張目視；水垢 4 張照片上的浮水印文字仍是「重水地區水垢處理」（燒在圖上，未處理）。
**未做**：H2（覆審本身應由 Codex 做）；B6 影片壓縮（仍需業主本機 ffmpeg）；H16 待業主。

### 2026-09-29（二）Claude 唯讀審查 `f18a808...5bc9b74` 案例頁改版＋業主新需求 H15

**範圍**：`65da6be`、`797999c`（主要 UI/UX）、`ccb48bf`、`5bc9b74`；實改 `src/cases.jsx`、`src/style.css`、`AI-README.md`、`DESIGN.md`。
在獨立 worktree 建置 production preview，以 Playwright Chromium 實測；**本輪未改程式碼**。

**結論：維持上線，未發現需要阻擋上線的問題。** 業主需求全部達成（前台無任何數量、三組上緣色線、44px 低圓角分段按鈕、
深色方角色章 vs 淺色圓膠囊、膠囊 32px 三等分、卡片完整顯示標籤、`grease-kitchen` 可由居家／商用＋廚房找到、統一「重油汙」）。

**自動檢查**：`pnpm install --frozen-lockfile` OK；`pnpm lint` exit 0；`pnpm build` exit 0；`git diff --check f18a808 5bc9b74` 無輸出；
五種寬度＋全部互動 Console warning／error 皆 0。

**視覺矩陣**：

| 寬度 | 篩選欄 | 卡片欄 | 水平溢出 | 按鈕最小高 | 卡片標籤 | 同列卡片等高 |
|---|---|---|---|---|---|---|
| 375 | 1 | 1 | 0 | 44px | 全部 96×32 | ✅ |
| 768 | 1 | 2 | 0 | 44px | 全部 96×32 | ✅ |
| 882 | 2＋第三組橫跨（5 欄選項） | 2 | 0 | 44px | 全部 113×32 | ✅ |
| 1280 | 3 | 3 | 0 | 44px | 全部 108×32 | ✅ |
| 1440 | 3 | 3 | 0 | 44px | 全部 126×32 | ✅ |

**行為**（1280 實際點擊）：居家＋廚房→廚房重油汙、一般居家清潔 ✅；商用＋廚房→廚房重油汙、商業廚房清潔 ✅（同群自動切換）；
廚房＋水垢→無結果 ✅；個別取消、再點取消、取消全部、無結果「查看全部案例」皆 ✅；居家＋衛浴＋水垢→只剩水垢處理 ✅；
卡片與下方抽屜每一步一致 ✅；點卡片→hash 更新、抽屜展開、照片載入 ✅；375 開 `#move-in-cleaning` 先載 4 張、捲完 27 張全載、無零高度 ✅；
鍵盤 Tab 有 3px focus 外框、Enter／Space 切換 `aria-pressed` ✅；選取有勾選圖示（不只靠顏色）✅；reduced-motion 下卡片不浮起、無 transition ✅。

**對比**：三組標題 5.86／5.50／5.84、三組選取按鈕同值、卡片標籤 5.00、查看現場照片 5.86、已選 chip 7.87、取消全部 8.64 皆過 AA；
**分類色章 4.41 未過（H10）**。

**Findings → 待辦**：P2 = H9（縮圖 3.76 MB）、H10（色章對比）、H11（`#album-finder` 不捲動，`f18a808` 同樣 scrollY 0，屬既有問題）；
P3 = H12（aria-label）、H13（無結果缺 LINE）、H14（375 h2>h1）。另校正本檔兩處：第 10 行「三種寬度」→四種；（七）「只在展開抽屜才載入」加註已失效。
主觀建議未列待辦：部分縮圖首張含「處理前／清潔後」字卡，16:10 裁切會切字；首屏大圖與第一張卡片為同一張照片。

**H15｜業主需求：「重水地區水垢處理」併入「一般居家清潔」**（業主 2026-09-29 決定，理由：內容重複）

**業主 2026-09-29 已確認為「合併相簿」**：不再有獨立的水垢相簿，4 張照片移到一般居家清潔。步驟：

1. **搬照片（不刪）**：`public/cases/scale-removal/scale-removal-01..04.jpg` → `public/cases/general-home-cleaning/general-home-cleaning-12..15.jpg`（`git mv`），刪空資料夾。
2. **`src/cases.jsx`**：刪 `scale-removal` 相簿物件；`general-home-cleaning` 的 `generatedPhotos(...)` 張數 11→15；`tags` 補「水垢」（成為 `['居家','全室','廚房','衛浴','地板','水垢']`，仍 ≤6 個，卡片兩列不變）。
   `isComposite` 是相簿層級，新進 4 張不是拼圖但以 `contain` 顯示只會多留白、不會裁切，可接受。
3. **舊連結相容**：`getAlbumFromHash` 加別名，`#scale-removal` → `general-home-cleaning`（外部或 LINE 可能分享過舊連結）。
4. **`src/main.jsx`**：`:162`「局部加強需求」圖片改指 `general-home-cleaning-12.jpg`（原 `scale-removal-01.jpg`，同一張）；
   `:204` 重點清潔 `items` 移除「重水地區水垢處理」；`:201` 重點清潔 `copy`「針對廚房重油汙、水垢、雨棚…」拿掉「水垢」。一般清潔群組文案是否補「水垢」由 Codex 依版面判斷，不要改動其他服務名稱。
5. **`cases/index.html` JSON-LD**：刪 `#scale-removal` 那筆 `hasPart`；一般居家清潔描述張數 11→15；總述「13 個相簿」→12（照片總數 105 不變）；`meta description` 的「水垢處理」可保留（一般居家仍含水垢）。
6. **`tools/watermark-cases.ps1:58`**（陷阱 11、12）：`scale-removal` 那列要改成輸出到 `general-home-cleaning` 並從 12 起編號，或刪除該列並加註；否則重跑腳本會把已刪的相簿重建出來。
7. 同步本檔第 1 節頁面結構的相簿數（13→12）、DESIGN.md 若有相簿數也一起改；全庫 `grep -rn "scale-removal\|水垢處理" . --exclude-dir=.git --exclude-dir=node_modules --exclude-dir=dist` 應只剩本檔歷史紀錄與第 3 步別名。

**H15 完成條件**：案例頁 12 個相簿；一般居家清潔 15 張、可由「水垢」「衛浴」篩到；「居家＋衛浴＋水垢」結果為一般居家清潔；
`/cases/#scale-removal` 會展開一般居家清潔；首頁「局部加強需求」圖片正常；lint／build 通過。

**本輪明確未驗**：正式站 `jjf.tw`（沙盒代理拒絕連線，全部以本機 production preview 驗證）；iOS Safari、Android Chrome、LINE 內建瀏覽器；
Firefox／Safari；螢幕閱讀器走讀（H12 依 Playwright accessible name 判定）；慢速網路下縮圖實際載入時間（只量了位元組）。


### 2026-09-29 Codex 重設案例頁標籤與案例卡視覺

**業主需求**：案例頁要讓消費者更直覺地辨認服務情境、空間部位與處理需求；三組做成不同色塊並放大置中主標題。案例卡的分類名稱與下方標籤需要明顯分層，文字不可全部靠左，且前台不要出現案件、照片、影片或標籤數字。

**完成內容**：

1. 移除 hero 統計、熱門速查數量、篩選旁件數、符合相簿數、卡片照片／影片數與 `＋N` 收合；保留「全部案例」、已選複合標籤、個別取消及「取消全部」。
2. 「服務情境／空間部位／處理需求」改為一致白底卡面，分別用青綠、沉穩藍、暖砂的上緣識別線、標題與選取狀態分組；選項改成規整的低圓角分段按鈕，移除大面積粉彩與氣泡感。主標題置中放大但收斂最大字級，避免壓過操作區。
3. 案例索引卡改用實拍縮圖，內容置中；分類（例如裝潢細清、特殊清潔）用深青綠方角色章，需求標籤用淺色圓膠囊並水平平均分配。膠囊固定 32px 高、每列三等分，單列與換行卡片不再因剩餘高度產生不同尺寸，並完整顯示所有標籤。
4. 相簿抽屜移除數量膠囊，改顯示完整標籤；可見的照片與影片 caption 改成「案場實拍／現場影片」，不再帶序號。
5. H1：案例頁「← 回首頁」由 9px 調為 11px；H5：廚房重油汙補「居家／商用」；H6：全數統一為「重油汙」。
6. 依 `D:\AI-Skill\ai-skills\SKILL.md` 路由到 `uiux-design` 後再做視覺審計：案例速查定位為信任導向的在地服務目錄，保留既有品牌青綠與三組辨識色，但把大面積粉彩、氣泡形按鈕與彩色陰影收斂為白色卡面、4px 上緣識別線、10px 低圓角分段按鈕及中性陰影。820–1179px 使用兩欄＋第三組橫跨整列，1180px 起才並排三欄，避免處理需求被擠窄。

**驗證**：

- `pnpm lint` exit 0；`pnpm build` 成功（Vite 6.3.5，1633 modules）；`git diff --check` 通過。
- Chromium 實測 375／768／882／1280：`documentElement.scrollWidth` 與 body 寬度一致，無水平溢出；篩選按鈕最小高度 44px。882px 顯示兩欄＋第三組橫跨整列，1280px 顯示三等欄。
- 互動實測：「居家＋廚房」只顯示廚房重油汙與一般居家清潔；可個別取消、取消全部；「廚房＋水垢」無結果時可用「查看全部案例」回復；抽屜可展開並載入照片。
- Console 無 warning／error。
- 基礎功能 commit `65da6be`、UI/UX 收斂 commit `797999c` 均已推至 `main`；GitHub Pages run `36508050506` 成功。線上 `https://jjf.tw/cases/` 與 CSS asset `style-BC9ShQZQ.css` 均回應 HTTP 200（Last-Modified 2026-09-29 01:28:47 UTC）。

**本輪明確未驗**：尚未在真實 iOS／Android 與 LINE 內建瀏覽器實測；尚未用螢幕閱讀器完整走讀；H2、H3、H8 未在本輪處理；H7 仍待業主決定。

### 2026-09-28（七）Claude 量測案例頁載入量，決定只壓部分照片（H8）

**業主問題**：是否要把所有照片壓縮，加快案例頁讀取？**結論：不需要全部壓，只壓 23 張大圖（H8）＋影片（B6）。**

**量測**（`pnpm build` 後 `pnpm preview`，Playwright Chromium，記錄所有 response body 大小）：

| 情境 | 下載量 |
|---|---|
| 打開 `/cases/`（375 與 1280 相同） | **0.32 MB**，圖片 2 張 0.05 MB，影片 0 |
| 手機開 `#commercial-kitchen` 並捲到底 | 追加 2.95 MB（影片未下載，`preload="metadata"`） |

相簿照片只在展開抽屜時才載入，首屏已經很輕。
（⚠️ 2026-09-29 更新：`797999c` 起案例卡改用實拍縮圖，此句已不成立；捲過卡片列表會載入 13 張原檔，見 H9。）

**照片現況**（`public/cases/` 105 張，共 30.07 MB）：

| | 張數 | 大小 | 平均 |
|---|---|---|---|
| 已壓縮（move-in／general-home） | 38 | 9.45 MB | 254 KB |
| 未壓縮（其餘 11 相簿） | 67 | 20.62 MB | 315 KB |
| 其中最長邊 >1600px | 23 | 7.31 MB | 約 325 KB（commercial-kitchen 部分達 900 KB） |

未壓縮的 67 張平均只比已壓縮的多約 60 KB，全部重壓估計只省約 4 MB，且分散在 11 個相簿，
每次開相簿的體感差異小。效益集中在 >1600px 的 23 張（尤其商業廚房 1350×1800），故只排 H8。

**本輪明確未驗**：H8 壓縮後的實際節省量（沙盒無 PIL／ImageMagick，未試壓）；真實手機網路下的開相簿時間。

### 2026-09-28（六）Claude 覆審 E2 案例頁標籤語意（H4）

範圍：`d55cb21` 的 13 個相簿 `tags` 與 `filterGroups`。只做靜態比對（`tags` × `filterGroups` × 各相簿 `copy`），
**未改程式碼**（Codex 正在改同檔）。篩選邏輯本身正確：13 個相簿的標籤全部屬於某一群，沒有孤兒標籤；
同群單選、跨群 `every(includes)` 交集行為與 Codex 描述一致。

各相簿在三群的落點：

| 相簿 | 服務情境 | 空間部位 | 處理需求 | 判定 |
|---|---|---|---|---|
| 裝潢細清 | 裝潢 | 全室 | 粉塵 | ✅ |
| 垃圾清運 | 退租入住、特殊處理 | 全室 | 清運 | ✅（浮水印原本就標「退租清運」） |
| 除霉 | 居家、特殊處理 | 衛浴 | 除霉 | ✅ |
| 油漆清潔 | 裝潢、特殊處理 | —（牆面／天花板無對應選項） | 油漆 | ✅ 可接受 |
| 廚房重油汙 | **—（缺）** | 廚房 | 重油污 | ❌ 見發現 2 |
| 水垢處理 | 居家 | 衛浴 | 水垢 | ✅ |
| 洗雨棚 | 居家 | 門窗戶外 | — | ✅ |
| 地板除膠 | 裝潢、特殊處理 | 地板 | 除膠 | ✅ |
| 木地板清潔 | 居家 | 地板 | 木地板 | ✅ |
| 洗地打蠟 | 商用 | 地板 | 洗地打蠟 | ⚠️ 見發現 1 |
| 一般居家清潔 | 居家 | 全室、廚房、衛浴、地板 | — | ✅ |
| 退租入住清潔 | 退租入住 | 全室、廚房、衛浴、地板、門窗戶外 | — | ✅ |
| 商業廚房清潔 | 商用 | 廚房 | 重油污 | ✅ |

**發現**：

1. **洗地打蠟歸「商用」有疑慮（→ H7，需業主）**。`copy` 寫的是「停車位、磁磚與地面」，
   早期相簿也叫 `parking-floor-cleaning`。停車位多半是社區大樓（管委會）案場，對消費者來說不是「商用」。
   現況：選「居家」看不到洗地打蠟。建議請業主確認實際客群，三個選項：
   (a) 改標「居家」＋「商用」兩個（最簡單，但同群單選下兩者各自都找得到）；
   (b) 服務情境新增「社區大樓」；(c) 維持「商用」。Claude 建議 (a)。
2. **廚房重油汙沒有任何服務情境標籤（→ H5）**。只要選了任一服務情境，這個相簿就一定被濾掉；
   例如「居家＋廚房」只剩一般居家清潔，「商用＋廚房」只剩商業廚房。`copy`（爐台、牆面、設備周邊、長期油垢）
   看不出是住家或店面。**業主 2026-09-28 回覆：兩者都有** → 補「居家」「商用」兩個標籤。
3. **「特殊處理」放在「服務情境」群語意不太對（低優先，不必改）**。它其實是處理類型，與「居家／裝潢」不在同一維度，
   且同群單選，所以無法組出「居家＋特殊處理」。目前 4 個特殊處理相簿都另有情境標籤，實際影響小；
   若之後特殊清潔相簿變多，再考慮移到「處理需求」或改成獨立開關。
4. **用字不一（→ H6）**：標籤「重油污」vs 標題「廚房重油汙」。
5. 一般居家清潔、退租入住清潔、洗雨棚沒有「處理需求」標籤——屬綜合型服務，合理，不需補。

**本輪明確未驗**：未在瀏覽器實際點選篩選（邏輯為純 `includes`，以靜態比對判定）；未看照片內容逐張確認標籤，
只依 `copy` 與既有註解判斷。

### 2026-09-28（五）修正首頁與案例頁 header 三處不一致（Claude）— ⚠️ 請 Codex 覆審

程式碼在 `5740012`，本段為補記（該 commit 漏更新本檔）。

**修正內容**：

1. **首頁 header 加電話鈕**：`src/main.jsx` 在 LINE 與粉專之間加 `.header-action.phone-action`，
   與案例頁一致為 LINE／電話／粉專。首頁 header 聯絡鈕仍只在 ≥1280px 顯示；
   820–1279px 沿用既有規則收起 `.header-actions`，由底部 dock 承接（見陷阱 9／10 相關段落）。
2. **案例頁加「← 回首頁」**：`src/cases.jsx` 品牌連結內新增 `.brand-back-label`（9px、muted 色）。
3. **案例頁 logo 尺寸對齊首頁**：行動版 `clamp(112px, 33vw, 132px)` → `clamp(96px, 26vw, 118px)`、
   `max-height` 52→46px；≥820px 新增 `clamp(130px, 11.5vw, 160px)`。

**驗證**（`pnpm build` 後 `pnpm preview`，Playwright Chromium 量測）：

| 頁面 | 寬度 | 導覽最右 → 聯絡鈕左緣 | header 高 | 水平溢出 |
|---|---|---|---|---|
| 首頁 | 1280 | 912 → 1040（間距約 128px） | 95px | 無 |
| 首頁 | 1366 | 966 → 1123（約 157px） | 95px | 無 |
| 首頁 | 1440 | 1008 → 1195（約 187px） | 95px | 無 |
| 案例頁 | 375 | —（無導覽） | 64px | 無 |
| 案例頁 | 1280 | —（無導覽） | 84px | 無 |

- 多一顆電話鈕後 1280 仍無重疊（2026-09-10 紀錄中 1280 只剩 6px 間距，是當時 header 設定下的量測；
  現況實測間距約 128px）。
- `pnpm lint` 0 error；`pnpm build` 成功。

**本輪明確未驗**：真機（iOS／Android）上「← 回首頁」9px 字的可讀性（見待辦 H1）；
820–1279px 首頁底部 dock 的電話鈕行為未重新量測（本輪未改該區段）。
### 2026-09-28（四）Codex 重構案例頁為複合標籤速查

**業主需求**：原案例頁分類與色彩過多，希望像露營區速查一樣，可用廚房、衛浴、裝潢、退租、商用等標籤快速找到案例，並方便未來擴充。

**資訊架構**：

1. 移除 hero 的四大分類矩陣，改為五個熱門入口：廚房、衛浴、裝潢、退租入住、商用。
2. 相簿資料新增 `tags`，速查分成「服務情境／空間部位／處理需求」三群；同群單選、跨群取交集，例如「退租入住＋廚房」只顯示退租入住清潔。
3. 篩選結果同步控制索引卡與下方相簿抽屜，避免索引已縮小、頁面下方仍堆滿所有相簿。
4. 索引卡改為一致青綠色階，顯示最多三個關鍵標籤；移除依排列位置套多種顏色與抽屜色系的做法。
5. 無結果時提供解釋與一鍵重設；每個標籤顯示目前資料中的相簿數，所有數字從 `albums` 推算。

**驗證**：

- `pnpm lint` exit 0；`pnpm build` exit 0（1633 modules）。
- 互動：廚房 → 4 個相簿；廚房＋退租入住 → 1 個相簿且只剩「退租入住清潔」；廚房＋水垢 → 0 個相簿並顯示無結果提示；一鍵清除回到 13 個。
- 相簿入口點擊後 hash、`aria-expanded` 與 27 張照片 DOM 正確；同時只開一個抽屜。
- 375／768／1280 viewport：水平溢出皆為 0；375px 的篩選按鈕高度皆至少 44px；1280px 篩選為三欄、索引為三欄。
- 瀏覽器 console error 0；未改圖片載入、聯絡連結或 JSON-LD。

**本輪明確未驗**：

- 尚未部署到 `jjf.tw` 做正式站複驗。
- 未在真機 LINE 內建瀏覽器操作；本輪使用 Edge viewport 模擬 375／768／1280。
- 標籤語意與個別案例內容仍請 Claude／業主覆審，尤其「洗地打蠟」是否歸商用情境。

### 2026-09-28（三）Codex 覆審兩個新相簿、修正 lazy-load 並壓縮照片

**覆審結論**：Claude 的相簿資料、`generatedPhotos()` 參數、`Home`／`KeyRound` 使用、
JSON-LD 13 相簿／105 張，以及 `isComposite` 只套用兩個新相簿的範圍皆正確；但線上行為有一個
阻斷問題：`height:auto` 讓 lazy 圖片在載入前高度為 0，導致照片完全不載入。

**修正內容**：

1. `src/style.css` 的 `.album-photo-card.is-composite img` 加入 `aspect-ratio: auto 3 / 4`，
   未載入前先保留 3:4 高度，載入後使用每張照片的實際比例，仍以 `contain` 完整顯示拼圖。
2. 38 張新增照片依管理工具既有規格縮到最長邊 1600px、JPEG quality 82；方向皆為 Orientation 1。
   總量由 20.43 MB 降到 9.45 MB（減少 53.7%），一般居家 11 張、退租入住 27 張，缺檔 0。

**驗證**：

- `pnpm lint` exit 0、`pnpm build` exit 0；`dist/` 產生 135 個檔案。
- GitHub connector 確認 `90d22da` 與 `f87753e` 的遠端內容和本機一致。
- 線上部署複驗在修正前重現：一般居家 11 張皆為 `clientHeight=0`、`complete=false`，證實非單純網速慢。
- 其他 11 個相簿沒有 `isComposite`，原本固定高度與 `object-fit:cover` 規則不變。

**正式站複驗**：

- `ef32c0b` 推上 `main` 並完成部署後，`/cases/#general-home-cleaning` 11/11 張、
  `/cases/#move-in-cleaning` 27/27 張皆成功載入；零高度 0、破圖 0、CSS 為 `contain`，
  實際顯示比例與原圖比例一致，確認沒有裁切。
- 舊的 `/cases/#general-cleaning` 仍只有 `album-photo-card`，10 張皆維持 `object-fit:cover`。

**本輪明確未驗**：未新增浮水印；維持業主原始拼圖內容，避免重跑既有一對一浮水印腳本造成陷阱 12 的分類問題。

### 2026-09-28（二）拼圖照片改為完整顯示（Claude）— ⚠️ 請 Codex 覆審

**問題根源**：`general-home-cleaning` 與 `move-in-cleaning` 的照片均為 LINE 匯出的拼圖（每檔含 2×2 或 2×3 子圖，左欄=清潔前、右欄=清潔後）。原本 `.album-photo-card img` 的 `height: clamp(230px, 62vw, 360px)` + `object-fit: cover` 會把拼圖裁切，消費者看不到完整的前後對比格子。

**修正內容**：

1. **`src/cases.jsx`**：在 `general-home-cleaning` 與 `move-in-cleaning` 兩個相簿 entry 各加 `isComposite: true` 旗標。於 photo card render 加入 `${album.isComposite ? ' is-composite' : ''}` class。
2. **`src/style.css`**：新增規則：
   ```css
   .album-photo-card.is-composite img {
     height: auto;
     object-fit: contain;
     background: var(--color-surface);
   }
   ```
   覆寫有旗標相簿的圖片顯示方式，其他 11 個既有相簿不受影響。

**驗證**：
- 語法目視確認（JSX class 拼接、CSS 選取器正確）。
- **未跑 `pnpm lint` 與 `pnpm build`**，請 Codex 覆審。
- **未在瀏覽器實測拼圖顯示效果**，部署後請開 `/cases/#general-home-cleaning` 與 `/cases/#move-in-cleaning` 確認照片完整不裁切。

---

### 2026-09-28（一）新增一般居家清潔＋退租入住清潔相簿（Claude）— ⚠️ 請 Codex 覆審

**業主需求**：提供 38 張清潔前後對比照，要求在案例頁新增前後對比圖片展示區（一般清潔、退租入住各一類）。

**動手前先查到的事**：
- 待辦 C6（退租入住相簿等素材）、E1（首頁一般清潔無對應相簿）皆與本輪直接相關。
- 照片已由業主放入 `C:\AI\網站\清潔網站-潔淨坊\案例圖片\一般清潔-退租入住\` 資料夾，共 38 張 LINE 匯出格式。

**修正內容**：

1. **新增 `public/cases/general-home-cleaning/`**（11 張）：原始批次 S__230604819～S__230604829，命名為 `general-home-cleaning-01.jpg`～`general-home-cleaning-11.jpg`。
2. **新增 `public/cases/move-in-cleaning/`**（27 張）：原始批次 S__230612998～S__230613023 共 24 張，加上 S__231047186～S__231047188 共 3 張（全室完工實景），命名為 `move-in-cleaning-01.jpg`～`move-in-cleaning-27.jpg`。
3. **`src/cases.jsx`**：新增 `Home, KeyRound` 圖示匯入；在 `commercial-kitchen` 前插入兩個新相簿（`general-home-cleaning` 和 `move-in-cleaning`），分類皆為「重點清潔」，解決待辦 C6 與 E1。
4. **`cases/index.html` JSON-LD**：更新 `description` 為 13 個相簿、105 張照片；新增兩個 `ImageGallery` 節點（`#general-home-cleaning`、`#move-in-cleaning`）；更新 meta `description` 補入一般居家清潔與退租入住。

**⚠️ 照片注意事項**：
- 本輪照片直接複製自業主 LINE 匯出，**尚未過 `tools/watermark-cases.ps1` 浮水印腳本**。
- 照片本身部分已帶有工作背心（寫有「專業清潔 0983531549」）等品牌識別，短期可先上線。
- 若業主後續要統一浮水印風格，需在 `watermark-cases.ps1` 的 mapping 加入這兩個相簿的來源路徑，並注意陷阱 12。
- 照片為 LINE 原圖（約 2160×2880px），尺寸偏大；建議 Codex 跑一次調整大小，或使用 `cases/manage/` 工具壓縮。

**驗證**：
- 38 張照片複製完成，`general-home-cleaning` 11 張 / `move-in-cleaning` 27 張，filename 逐一確認。
- `src/cases.jsx` 語法人工目視確認（兩個新相簿 entry 格式與現有相簿一致，`generatedPhotos()` 呼叫參數正確）。
- JSON-LD 節點計數：原 11 個 `hasPart` → 現 13 個，數字標注已更新。

**本輪明確未驗**：
- **未跑 `pnpm lint` 與 `pnpm build`**（本機未安裝 pnpm，沙盒限制）。請 Codex 在推 main 前跑一次。
- **未在本機 preview 確認相簿抽屜展開與照片載入**。
- 照片未壓縮，檔案大小視覺影響未測。

### 2026-09-24 OG 服務地區改五個地區＋新增「退租入住」情境卡（Claude）— ⚠️ 請 Codex 覆審

**業主需求**（LINE 截圖）：
1. 分享卡片上的服務地區從「基隆・雙北・桃園」改成「林口、龜山、基隆、雙北、桃園」。
2. 「可以再增加一項退租入住的內容嗎」。

**動手前先查到的事**：退租入住**本來就在站上**——首頁「一般清潔」卡片的項目清單與說明文、
OG 圖的服務內容膠囊、分享頁 description 都有。所以業主要的不是再放一個字，而是一項找得到的服務。
跟使用者確認後決定：**在首頁「需求情境」新增一張具名的情境卡**（不開新相簿，因為沒有素材）。

**修正內容**：

1. **OG 文字（三頁 meta）**：`index.html`／`cases/index.html`／`share/index.html` 的 `og:title`、
   `og:description`、`description`、`og:image:alt`，以及 share 頁的 `<title>`，服務地區全部改成
   「林口・龜山・基隆・雙北・桃園」。首頁 JSON-LD 的 `areaServed` 本來就已含新北市林口區與桃園市龜山區，不需要改。
2. **重產 OG 圖**：地區帶從 4 個地區單行 50px 改成 5 個地區兩行 44px（膠囊高 118→140），
   以下元素整體下移 22px。單行塞五個地區會把字級壓到 38px，反而弱化業主最在意的這一行。
3. **新增 `scripts/generate-og.py`**：`generate-og.ps1` 需要 Windows＋System.Drawing，沙盒跑不了。
   移植成 Pillow 版本，字型取 Google Fonts 的 **同一個** Noto Sans TC 家族（PS1 用的就是 NotoSansTC-VF）。
   **兩支必須同步修改**，見新增的陷阱 14。本輪 PS1 與 PY 的文案、座標已對齊。
4. **首頁新增「退租入住」需求情境卡**（`src/main.jsx`）：標題「退租入住」、標籤「點交前後」、
   `KeyRound` 圖示、底圖用 `general-cleaning/general-cleaning-01.jpg`（空屋櫃體點交現場，先前沒有任何情境卡用到）。
   文案只描述服務範圍與「先用照片對齊」，不寫價格、不放成果數字，守住第 2 節內容邊界。
5. **同時收斂原本的「搬入搬出前後」**：它原本的文案是「空屋、租屋交接、入住前重整」——
   那本來就是退租入住，兩張卡會講同一件事。已改成純搬家情境（家具搬動、空屋清空、搬遷前後粉塵）。
6. **情境卡版面 5 → 6 張**（`src/style.css`）：原本的規則是為 5 張調的——
   820–1179px 用 `repeat(6,1fr)` 搭配第 4、5 張 `span 3` 排成 3+2；≥1180px 用 `repeat(5)` 一列排滿。
   6 張時這兩條都會讓末列落單，已改成 820–1179px 移除 nth-child 特例（3+3）、≥1180px 改 `repeat(3)`（3+3）。
7. **新增 `.scenario-handover` 色系**：前 5 個 tone 已用掉青／藍／綠／橘／紫，第 6 個再加彩度會變成彩虹，
   改用低彩度板岩色（`#5f7486`）收尾。

**驗證**：

- `pnpm lint` exit 0、`pnpm build` exit 0。
- 情境卡版面實測 320／390／414／600／768／820／1024／1180／1280／1440 共 10 個寬度：
  <820px 單欄、≥820px 一律 3 欄 3+3，**水平溢出全部 0、每列卡片等寬、末列不落單**。
- 六張情境卡的文字對比像素級量測（新的板岩色卡是第 2 張）：
  標題 7.39–9.77、內文 6.61–8.01、標籤 7.58–9.94，**全部通過 AA**。
- axe-core（wcag2a/aa、wcag21a/aa、wcag22aa、best-practice）兩頁 × 390／1440：
  violations 各 1，且都是 `.final-cta .eyebrow` 那個已知誤判（axe 看不到漸層底，像素量測實為 7.51）；
  passes 首頁 45、案例頁 37。
- 六張情境卡的底圖實測全部有載入（含新卡的 `general-cleaning-01.jpg`），`loading="lazy"` 維持有效。
- OG 圖移植正確性：拿舊圖未改動的元素做逐像素互相關，位移 0–3px（logo 0,0）。

**本輪明確未驗**：

- **線上 `jjf.tw` 與分享卡片實際效果完全沒驗**：沙盒 proxy 對該網域回 403。
  部署後請務必用 LINE 與 FB 各分享一次，確認卡片抓到新的 og:title 與新圖。
  **社群平台會快取 OG**，舊卡片可能要用 FB 分享偵錯工具或改 `?v=` 參數才會更新。
- `scripts/generate-og.ps1` **沒有實際在 Windows 上重跑過**。本輪 commit 的圖是 PY 版產生的；
  PS1 的座標已同步，但請 Codex 在業主機器上跑一次確認輸出一致。
- 真機 LINE 內建瀏覽器的首頁情境卡版面。
- 未開退租入住案例相簿（見待辦 C6，需業主提供照片）。

### 2026-09-13 Codex 整體 UI/UX 高質感強化 — ⚠️ 請 Claude 覆審

**業主需求**：依目前結構做整體 UI/UX 強化，必要時可出圖；目標是讓網站像高質感服務品牌，而不是廉價的一頁式 AI 生成網站。

**同日補修**：業主指出首頁 4 個數字仍像普通文字、沒有設計感；已把 `.hero-proof-list` 改成 4 個彩色數據磚，每格置中、數字放大、使用不同主題色與淡色底。

**本輪設計判斷**：

- 不新增生成圖。此案目前最強信任資產是業主實拍案場照片、Google 商家評論與可查證相簿數；生成圖會稀釋真實感。
- 首屏不再把「潔淨坊」單純放大成品牌字，而是改成「照片先確認範圍／再安排到府服務」，把使用者下一步與業主服務流程放在第一眼。
- 降低膠囊、圓形裝飾與模板卡片感；保留既有 header 與 CTA 架構，避免再打破前幾輪修好的手機導覽／聯絡島邊界。

**修正內容**：

1. `src/main.jsx`：首頁 hero 文案改為價值主張優先，品牌名收進副標；新增 4 個數字錨點（67 張實拍照片／11 個案場相簿／4 大類清潔需求／31 則 Google 評論）。
2. `src/main.jsx`：新增 `assurance-strip`，用「費用不先寫死／照片先對齊範圍／只放實際素材」三句風險逆轉，守住不虛構價格、案例與評論的內容邊界。
3. `src/main.jsx`：hero 實拍圖加 caption，說明照片用途是先對齊櫃體、木作、粉塵與局部細節，強化專業服務感。
4. `src/cases.jsx`：案例頁 hero 新增動態統計，從 `albums` 推算相簿數、照片數與影片數，不手寫死數字。
5. `src/style.css`：新增暖白 surface、深墨綠文字與紙張陰影 token；首頁 hero 改成 editorial band，收斂模板式巨大品牌字、過重膠囊與背景裝飾。
6. `src/style.css`：trust band 改為自然分隔的信任列，scenario 卡片改淡化裝飾、讓實拍照片承擔質感；案例頁首屏與四大矩陣背景也移除過度 radial 裝飾。
7. `src/style.css`：同日補修首頁數字錨點，改成彩色數據磚；390px 下每格 78px 寬、標籤置中，未與底部聯絡浮島重疊。
8. `DESIGN.md`：同步目前實作：LINE 深綠對比色、首頁價值主張優先、數字錨點與實拍信任策略。
9. `public/sitemap.xml`：首頁與案例頁 `lastmod` 更新為 `2026-09-13`。

**驗證**：

- `pnpm lint` exit 0。
- `pnpm build` exit 0（沙盒內因 Windows/esbuild 權限無法讀 Vite config，解除沙盒後同命令通過）。
- `git diff --check` exit 0。
- 本機 preview `http://127.0.0.1:4173/` 實測：
  - 390px 手機首頁：水平溢出 0；主標為「照片先確認範圍／再安排到府服務」；數字錨點未與底部聯絡浮島重疊。
  - 390px 手機首頁補修後：4 個數據磚水平溢出 0；每格文字 `text-align:center`；4 個數字各自套用不同主題色；未與底部聯絡浮島重疊。
  - 390px 手機案例頁：水平溢出 0；header 64px；案例統計列與四大矩陣可讀，未與右上聯絡鈕重疊。
  - 1280px 桌面首頁：水平溢出 0；導覽與右上 LINE／粉專按鈕未重疊。
  - 1280px 桌面案例頁：水平溢出 0；header 與四大矩陣正常。

**本輪明確未驗**：

- 真機 LINE 內建瀏覽器（iOS／Android）首屏視覺與 CTA 跳轉。
- PageSpeed／CrUX 實地數據。
- 螢幕閱讀器實測。
- 線上 `jjf.tw` 部署後畫面與社群分享快取。

### 2026-09-12 上架前全站稽核與修正（Claude）— ⚠️ 請 Codex 覆審

**做法**：建置 `dist` → 本機 server → Playwright 在 320／360／390／414／480／600／768／820／1024／1280／1440
共 11 個寬度開站，跑 axe-core、Core Web Vitals（Fast-3G 1.6Mbps/150ms + CPU 4× 節流）、
像素級對比量測、JSON-LD 對程式碼與磁碟的逐項比對、死資產全庫掃描。所有數字都是實測。

**稽核結論**：無 P0 阻斷項。P1 六項、P2 十二項，本輪修掉 P1 五項與 P2 十項。

#### 已修正（全部實測複驗過）

| 項目 | 修正前 | 修正後 |
|---|---|---|
| 首頁首屏（390×844，不捲動） | 1,975 KB | **1,177 KB** |
| 案例頁首屏 | 722 KB | **314 KB** |
| 案例頁 LCP（節流） | 3.98 s | **2.27 s** |
| `.step-list small` 對比 | 2.57 | **5.66** |
| `.step-list strong` 對比 | 3.46 | **5.59** |
| `.button.dark-secondary` 對比 | 3.57 | **5.23** |
| `.note-panel p` 對比 | 3.45 | **5.67** |
| hero／案例頁 eyebrow 對比 | 4.26 | **5.23** |
| 「在 Google 查看全部」連結 | 3.86 | **5.81** |
| 商家電話／LINE 連結 | 3.62 | **5.50** |
| axe-core violations | 5 種 | **0**（唯一殘留是漸層底的已知誤判，像素量測 7.51） |
| `public/` | 44 MB | **40 MB** |

1. **P1-1 首屏瘦身**
   - `logo-horizontal-transparent.png` 241 KB／720×356 → **28 KB／480×237**（quantize 256 色，
     目視與原圖無差異；OG 腳本只畫到 270×134，尺寸仍充足）。
   - `favicon-transparent.png` 219 KB → **23 KB**（維持 512×512，apple-touch-icon 品質不變）。
   - scenario 五張背景圖改成真正的 `<img loading="lazy">`（見陷阱 1）。
   - hero 補 `fetchPriority="high"`，`width/height` 從寫反的 `1478×1108` 改為正確的 `1108×1477`。
   - header／dock 的品牌 SVG 圖示拿掉 `loading="lazy"`（各 0.3–0.5 KB，在首屏，lazy 只會延後繪製）。
2. **P1-2 服務流程／LINE 詢問資料整段白字補到 AA** — 見新增的陷阱 13，底色與兩層白色疊層要一起改。
3. **P1-3 FAQ 第 3 題與同頁 Google 評論區自相矛盾** — 原句「不放未經確認的客戶名稱、評論」，
   但同一頁就列著兩則具名 Google 評論與 4.5★/31 則。已改寫成「只逐字引用 Google 商家上
   可公開查證的內容，標明作者與時間並附商家連結；不自行編寫或轉述客戶說法」，守住第 2 節
   內容邊界又與畫面一致。**評論區本身沒問題**：沒有誤用 `Review`／`AggregateRating`（已驗證）。
4. **P1-4 `<title>` 補地理詞** — `og:title` 本來就有「基隆・雙北・桃園」，但 SERP 用的 `<title>` 一個地名都沒有。
   首頁改「林口・龜山清潔公司｜潔淨坊清潔工作室」、案例頁改「清潔案場實拍相簿｜林口潔淨坊清潔工作室」。
5. **P1-5 `/share/` 加 `noindex, follow`** — 原本自我 canonical、無 robots meta、不在 sitemap，
   是一個可被索引的薄頁。FB／LINE 取 OG 不看 robots meta，**分享卡片不受影響**。
6. **P2-1 相簿張數膠囊在手機溢出**（本輪之前「＋影片」造成）— `.album-drawer .case-album-heading`
   在 <820px 把 meta 塞進寫死 46px 的 icon 欄，「8 張＋影片」需要 55px。第一欄改 `auto`。
7. **P2-3 五個 `<div aria-label>` 無 role** — ARIA 1.2 禁止，螢幕閱讀器完全忽略。
   兩個補 `role="group"`，三個直接移除（子連結本身已有名稱）。
8. **P2-4 skip link 不移動焦點** — `<main>` 補 `tabIndex={-1}`，實測按 Enter 後焦點確實落在 `MAIN#main-content`。
9. **P2-5 圖片尺寸屬性說謊** — 首頁 casePhotos 改成逐張帶 `w`/`h`（六張裡有一張是橫的）；
   案例頁相簿照片共 **13 種長寬比**，宣告單一尺寸必然錯，直接不宣告並註明原因（CLS 實測為 0）。
10. **P2-6 `twitter:card`** — `og:image` 是 1200×1200 方圖，`summary_large_image` 會裁掉上下各約 25%，改 `summary`。
11. **P2-8 刪 3.66 MB 死資產** 並校正 DESIGN.md／README.md 指向（順帶關掉陷阱 3 的三個死檔）。
12. **P2-10 評論作者與時間間缺空格**（`{review.meta}· {review.when}`）。
13. **P2-11 加 `public/404.html`**；`robots.txt` 移除 `/cases/manage/` 的 `Disallow`
    （Disallow 會讓爬蟲讀不到那頁的 `noindex`，兩者互相抵銷；留頁面層級的 noindex）。
14. **P2-12 其他** — CI 在 Build 前加 `pnpm lint`；`prefers-reduced-motion` 補上漏掉的四個 `:active` 動畫；
    JSON-LD `telephone` 改 E.164 `+886983531549`。

#### 刻意不做（連同理由）

- **P1-6 GEO `<noscript>` 摘要**：兩頁的 `<body>` 對不執行 JS 的檢索器都是零字（curl 實證只有
  `<div id="root"></div>`）。加 `<noscript>` 不動架構就能補，但這屬於待辦 G4 的討論範圍，
  **業主已指定三方決議**，等業主、Codex、Claude 都同意再做。
- **C5 手機導覽觸控高度**：見待辦 C5，會撐破固定 96px 的 header，上架前不動 header。
- **B6 影片壓縮**：沙盒沒有 ffmpeg。
- **C4 粉專網址**：需業主確認哪一個是現行正式網址，不猜。

#### 驗證

- `pnpm lint` exit 0、`pnpm build` exit 0（Linux 上跑，無 Windows/esbuild 權限問題）。
- axe-core（wcag2a/aa、wcag21a/aa、wcag22aa、best-practice）兩頁 × 兩個寬度：
  violations 由 5 種降到 0（唯一殘留是 `.final-cta .eyebrow`，axe 看不到漸層底而誤判 1.08，
  像素量測實為 7.51；passes 由 40 升到 45）。
- 像素級對比：11 個代表元素全部達標，方法以 axe 已知值做控制組（誤差 <1%）。
- 11 個寬度 × 2 頁：水平溢出全部 0；CLS 實測 0；零 console error、零失敗請求、零 HTTP ≥400。
- 相簿張數膠囊：360／390／414／768px 全部不再溢出。
- Skip link 實測焦點落點正確；相簿抽屜 `aria-expanded`／`hidden`／hash 開闔仍同步。
- scenario 卡片與服務流程區目視比對：視覺等價，未走樣。
- 刪檔前照陷阱 11 全庫掃描（含 `tools/`、`scripts/`），刪後再掃一次確認零殘留引用。

#### 本輪明確未驗

- **線上 `jjf.tw` 完全沒驗**：沙盒的 agent proxy 對該網域回 403，所有量測都在本機 `dist` 產物上做。
  推上 main 後請務必在真實環境複驗一次，特別是新的 `404.html` 與 `/share/` 的 noindex。
- **頁尾 Google 地圖 iframe 未驗**：`maps.google.com` 同樣被沙盒擋，在我這裡顯示為破圖。
  這是沙盒限制不是網站缺陷，但請在真機確認一次。
- 未在真機 LINE 內建瀏覽器檢查快取刷新、影片播放與撥號跳轉。
- 首頁 LCP 2.58 s → 2.73 s，看起來略退但那是節流量測的跑次噪音（LCP 元素是文字
  `SPAN.hero-brand-name`，不受圖片影響），未做多次取樣確認。
- PageSpeed 實地數據（CrUX）未取，本輪只有實驗室值。
- 未重跑整支 `tools/watermark-cases.ps1`；陷阱 12 仍成立。

### 2026-09-12 Codex 補入油漆清潔完工照

**業主需求**：業主提供一張油漆清潔完工照片，要求補到油漆清潔案例相簿。

**修正**：

1. 新增 `public/cases/paint-cleaning/paint-cleaning-09.jpg`。來源為本輪 ChatGPT 附件 `1-Photo-1.jpg`，保留原圖上的「潔淨坊／除泡沫紙／除膠、油漆完成後」完工標示。
2. `src/cases.jsx` 的 `paint-cleaning` 相簿由 8 張改為 9 張；四大矩陣特殊清潔張數會自動更新為 25 張＋影片／共 4 個相簿。
3. `cases/index.html` JSON-LD 手動同步為 11 個相簿、67 張照片、2 支影片；油漆清潔節點改為 9 張與 1 支影片。
4. `tools/watermark-cases.ps1` 補註記：`paint-cleaning-09.jpg` 是附件補入，不在 D 槽來源 mapping 內；若重跑腳本，需另行補回或先移入來源端。

**驗證**：

- 目視檢查新增完工照：方向正確、內容為油漆清潔完工現場，原圖已含潔淨坊標示。
- `pnpm lint` 通過。
- `pnpm build` 通過（沙盒內若仍遇 Windows/esbuild 權限問題，需用外部執行重跑）。
- JSON-LD 以 Node 解析合法：11 個 `hasPart`，未含 `Review`／`AggregateRating`。

**本輪明確未驗**：

- 尚未在真機 LINE 內建瀏覽器檢查新增照片顯示與快取刷新。
- 未跑 Google Rich Results Test 線上驗證；本輪只做本機 JSON-LD 解析。
- 未重跑整支 `tools/watermark-cases.ps1`；陷阱 12 仍成立，且 `paint-cleaning-09.jpg` 需另行補回。

### 2026-09-11 Codex 修正油漆清潔 07／08 照片方向

**業主回饋**：油漆清潔相簿第 7、8 張照片方向不正確。

**修正**：

1. 重新從來源 `D:\網站設計\潔淨坊\案場照片\油漆清潔\S__227377171_0.jpg` 與 `S__227377172_0.jpg` 產出 `paint-cleaning-07.jpg`、`paint-cleaning-08.jpg`。
2. 兩張來源圖先順時針旋轉 90°，再依既有規格縮到最大邊 1800px、JPEG quality 84，並重新加上水平的「潔淨坊 清潔服務／油漆清潔」浮水印。
3. `tools/watermark-cases.ps1` 補上 `RotateClockwiseIndexes = @(7, 8)`，避免只旋轉已加浮水印成品造成浮水印直立，也避免後續重跑又產出橫躺照片。

**驗證**：

- 目視檢查 `paint-cleaning-07.jpg`、`paint-cleaning-08.jpg`：人物、牆面與浮水印方向皆正確。
- `tools/watermark-cases.ps1` 的旋轉規則位於 resize 與 Add-Watermark 前，符合本次修正順序。
- `tools/watermark-cases.ps1` 以 PowerShell AST parser 檢查語法無誤。
- `pnpm lint` 通過。
- `pnpm build` 通過（沙盒內仍因 Windows/esbuild 權限擋住 `vite.config.js`，改用外部執行重跑成功）。

**本輪明確未驗**：

- 尚未在真機 LINE 內建瀏覽器檢查線上快取是否已立即更新。
- 本輪只修正既有兩張輸出圖，未重跑整支 `tools/watermark-cases.ps1`；陷阱 12 仍成立，整支腳本仍不能安全重建跨來源的 `wood-floor-cleaning`。

### 2026-09-11 Codex 新增油漆清潔相簿

**業主需求**：`D:\網站設計\潔淨坊\案場照片\油漆清潔` 補充油漆清潔照片與影片，要求列入特殊清潔並新增相簿。

**修正**：

1. 新增 `public/cases/paint-cleaning/`：8 張照片輸出為 `paint-cleaning-01.jpg`～`paint-cleaning-08.jpg`，並保留 1 支 `paint-cleaning-video.mp4`。
2. 8 張照片已依既有相簿規格縮到最大邊 1800px、JPEG quality 84，並加上「潔淨坊 清潔服務／油漆清潔」浮水印；影片直接複製，未重新壓縮。
3. `src/cases.jsx` 新增 `paint-cleaning` 相簿，分類為「特殊清潔」，標題「油漆清潔」，含 8 張照片與 1 支影片。四大矩陣的特殊清潔張數會自動更新為 24 張＋影片／共 4 個相簿。
4. 案例頁相簿卡與抽屜 meta 改用 `albumCountLabel()`，有影片的相簿會顯示「＋影片」；既有商業廚房影片也會正確顯示。
5. 首頁服務分類同步：裝潢清潔移除「油漆後整理」；特殊清潔加入「油漆清潔」。
6. `cases/index.html` JSON-LD 手動同步為 11 個相簿、66 張照片、2 支影片，新增 `paint-cleaning` 的 `ImageGallery` 節點。
7. `tools/watermark-cases.ps1` 新增來源資料夾「油漆清潔」→ slug `paint-cleaning` 的 mapping。注意：陷阱 12 仍成立，整支腳本仍不能安全重建跨來源的 `wood-floor-cleaning`。

**驗證**：

- 來源資料夾確認有 8 張 JPG、1 支 MP4。
- 產出照片抽查：浮水印存在，第一張照片顯示正常。
- `pnpm lint` 通過。
- `pnpm build` 通過（沙盒內仍因 Windows/esbuild 權限擋住 `vite.config.js`，改用外部執行重跑成功）。
- JSON-LD 以 Node 解析合法：11 個 `hasPart`，縮圖缺檔 0，未含 `Review`／`AggregateRating`。
- 本機 preview `/cases/#paint-cleaning` 實測：油漆清潔抽屜自動展開，8 張照片與 1 支影片載入；四大矩陣特殊清潔顯示「24 張＋影片／共 4 個相簿」。
- 390／768 viewport override 量測：未出現水平溢出，新相簿標題與「8 張＋影片」可讀。

**本輪明確未驗**：

- 尚未在真機 LINE 內建瀏覽器檢查新增相簿與影片播放。
- 未重新壓縮影片，也未驗證手機網路下的影片載入成本。
- 未跑 Google Rich Results Test 線上驗證；本輪只做本機 JSON-LD 解析，需部署後再測 `https://jjf.tw/cases/`。

### 2026-09-11（三）CNAME、GA4 事件追蹤、案例頁結構化資料（Claude）— ⚠️ 請 Codex 覆審

業主就 G3／G4／G5 三項做了決議：**G3 做、G5 做、G4 待三方決議**（業主、Codex、Claude
都同意才動），另外追加「按鈕點擊計次」需求。

#### G3 — `public/CNAME` ✅

內容一行 `jjf.tw`，已確認進入 `dist` 產物。線上 `https://jjf.tw/CNAME` 回 200，
Pages 設定維持 `cname=jjf.tw`／`https_enforced=true`／憑證 `approved`，加檔案未破壞既有設定。

**為什麼要做**：用 Actions 部署時，每次部署會換掉整個網站內容。GitHub 官方建議把 CNAME
放進產物，否則某些情況（改 Pages 設定、repo 轉移、Pages 重新啟用）會讓後台的網域設定被清掉，
`jjf.tw` 失效、業主分享出去的 LINE 連結全部打不開，而且不會有人第一時間發現。

#### 事件追蹤（業主追加需求）✅ 埋點完成，**尚未開始收數據**

新增 `src/analytics.js`。完整說明見本檔第 5.5 節，重點：

- `GA_MEASUREMENT_ID` 目前是空字串 → 所有追蹤都是安全 no-op，不載入外部資源、不發請求。
  **業主填入 `G-XXXXXXXXXX` 後推 main 才開始收數據**（待辦 G6）。
- 事件：`contact_click`（line／phone／facebook × 區域）、`album_open`（相簿 × 來源）、
  `nav_click`（站內導覽與 Google 地圖）。
- **用一個事件委派接管全站 `<a>`**，不在每個連結掛 onClick。這個站有 13 個聯絡連結散在各處，
  逐個掛不只囉嗦，日後新增按鈕很容易漏掉、數據默默少算。委派是「預設全部追蹤」。
- 無論有無 GA 都寫入 `window.__trackLog`（上限 200 筆），Console 即可驗證埋點是否真的觸發。

**修掉一個數據品質問題**：相簿索引卡既是 `<a>` 又有明確 `trackAlbum`，同一次點擊會產生
`album_open` ＋ `nav_click` 兩筆造成重複計數。已加 `data-track-skip` 機制排除。
**日後為任何元素加明確追蹤時，記得同時加這個屬性。**

#### G5 — 案例頁結構化資料 ✅

`cases/index.html` 補上 `BreadcrumbList` ＋ `ImageGallery`（10 個相簿，各帶名稱、
代表圖、張數、描述），`about` 與 `provider` 指回首頁 business 的 `@id`。

**這一項的效果，數字最清楚**（線上實測）：

| 爬蟲在案例頁看得到的 | 大小 |
|---|---|
| `<body>` 可見文字 | **0 字**（CSR 空殼，G4 未處理） |
| `<head>` 內 JSON-LD | **4,170 位元組** ← 本輪新增 |

在 G4 決定之前，這 4 KB 是不執行 JS 的爬蟲**唯一**讀得到的內容。

⚠️ 這份 JSON-LD **沒有與 `src/cases.jsx` 自動同步**。相簿增減或改名時要手動改這裡，
檔案內已加註解提醒。

#### 順手

FAQ 第 4 題的服務地區說法補上林口與龜山，與同日新增的服務區標註一致。

#### 驗證

- `pnpm lint` 0 error；`pnpm build` 通過；`dist/CNAME` 確認存在。
- 案例頁 JSON-LD 以 `json.loads` 驗證合法（`@graph` 2 節點、10 個相簿），線上複驗一致。
- **事件追蹤實測 12 次點擊全部分類正確**：hero／dock／inquiry／business／reviews 的
  LINE、電話、粉專、地圖、站內導覽都各自歸到正確的 `area`；相簿從分類卡、索引卡、
  抽屜三種來源開啟都記到正確的 `source`；索引卡重複計數確認消除（1 次點擊 = 1 筆事件）。
- 線上 `https://jjf.tw/`、`/cases/`、`/CNAME` 皆 200。

#### 本輪明確未驗

- **GA4 端沒驗過**，因為還沒有 Measurement ID。目前只驗到「事件有正確產生並寫入
  `window.__trackLog`」，沒驗到「GA4 後台確實收到」。填入 ID 後請在 GA4 即時報表複驗一次。
- 未在真機／LINE 內建瀏覽器測事件追蹤。**`tel:` 與 LINE 連結會離開頁面**，GA4 預設以
  sendBeacon 送出應該不會遺失，但沒有實測過。
- 未驗證 Google 是否已抓取新的 JSON-LD（剛上線，需等索引）。
- 未跑 Rich Results Test 驗證結構化資料（建議 Codex 或業主跑一次）。

---

### 2026-09-11（二）商廚照片轉正、木地板獨立成相簿（Claude）

業主回報兩項：

**1. 商業廚房有照片沒轉正** — 實際檢查 16 張，`10`／`12`／`13` 三張橫躺（人物側躺），
已用 PIL 順時針旋轉 90° 重存。`09` 是俯拍地面無方向問題、`11`／`14` 本來就正確，未動。

三張的 EXIF Orientation 都是空的——浮水印腳本用 System.Drawing 處理時丟失了方向資訊，
所以無法靠 EXIF 自動轉正，只能逐張目視判斷。

**2. 兩張木地板照片要歸木地板清潔** — 業主後續補充：連同 `floor-adhesive-removal` 的
「木紋地板殘膠處理」那組，**都屬於木地板清潔而非殘膠處理**。

因此新建 `wood-floor-cleaning` 相簿（重點清潔，4 張）：
- `01`／`02` = 原 `floor-adhesive-removal` 01／02（木紋地板前後對比）
- `03`／`04` = 原 `commercial-kitchen` 06／07（木地板髒污特寫）

`floor-adhesive-removal` 剩 5 張並重新編號，`beforeAfter` 只留「地磚殘膠與髒污整理」；
`commercial-kitchen` 剩 14 張並重新編號。

**驗證**：資產引用雙向比對——程式碼引用 68 筆**缺檔 0**、未被引用檔案 **0**；
案例頁實測 10 個相簿、**總數仍 58 張**，四大矩陣自動更新為重點清潔 18 張／5 相簿、
特殊清潔 16 張／3 相簿。**張數自動計算的設計讓這次跨相簿搬移完全不用手改任何數字。**

**⚠️ 產生了陷阱 12**：此次跨來源重組後浮水印腳本已無法重建 `wood-floor-cleaning`，
直接重跑會讓抽走的照片回來、編號錯位，且三張轉正會變回橫躺。腳本檔頭已加同樣警告。

---

### 2026-09-11 SEO／GEO 審查＋業主四項需求（Claude）— ⚠️ 請 Codex 覆審

#### 一、⚠️ 上架報告與實測有落差，請以實測為準

`潔淨坊網站上架總結報告.docx` 有三處與我實測不符，業主可能因此誤判進度：

| 報告聲稱 | 實測（2026-09-11） |
|---|---|
| 「已勾選 Enforce HTTPS，網址會走安全連線」 | ❌ `https_enforced: false`，憑證狀態 `authorization_created`（**簽發中**） |
| 「http 會導向 https」 | ❌ 相反：舊網址 301 → **`http://jjf.tw/`**（HTTP） |
| 「Search Console 若顯示無法擷取，多半是時間差」 | ❌ **不是時間差**。`https://jjf.tw/` 實測連線失敗，而 sitemap 與 canonical 全寫 https，GSC 抓必然失敗 |

**追記（同日稍晚）：憑證已簽發完成，上述三項全部解決。** 複驗結果：
`cert.state=approved`、`https_enforced=true`、憑證 subject 為 `CN=jjf.tw`、
`https://jjf.tw/`、`/cases/`、`/robots.txt`、`/sitemap.xml` **四個 URL 全部 200**、
http 正確 301 導向 https。DNS 本來就完全正確（無 CAA 阻擋、無錯誤 AAAA、
A 記錄正好是 GitHub 四個 IP、www CNAME 也對），所以不必改任何設定，純粹是等簽發。
**現在可以去 GSC 重新提交 sitemap 了**（先前失敗是因為 https 連不上，不是時間差）。

#### 二、Google 商家：本站最強的資產，但流量被送去 FB

業主提供商家連結後查到：**4.5 星／31 則評論／387+ 張相片**，最早評論 6 年前。
這比網站本身（58 張照片、0 則評論）強得多。

**但商家的「網站」欄位指向 `facebook.com/chenli0775/`，不是 `jjf.tw`。**
清潔服務是地區型生意，Google 商家通常比網站 SEO 更早帶來詢問，這個欄位等於把流量送給 FB。
**改一個欄位，5 分鐘**，見待辦 G1。

#### 三、業主本輪四項需求（已完成）

1. **`20260909 案場紀錄` 實際是垃圾屋清運照片，不是裝潢細清** — 整個相簿改歸特殊清潔。
   slug `case-20260909` → `garbage-clearance`，title 改「特殊清潔 垃圾清運」，icon 改 `Trash2`。
   **實體目錄與檔名、浮水印腳本的 Slug／Prefix／Label 一併同步**（避免重蹈陷阱 11）。
   附帶發現：浮水印腳本的 Label 本來就標「退租清運」，**一直是前台分類標錯**。
   全 repo 掃描還揪出 `src/main.jsx:116` 也引用了這個路徑（首頁情境圖），只改 cases.jsx 的話首頁會 404。
2. **服務地區特別標註林口、龜山** — 新增 `serviceAreas` 常數，兩區加 `.area-item-primary`
   樣式與「最常到府」標記，文案改為「工作室位於林口，林口、龜山是最常到府的區域」。
   JSON-LD 的 `areaServed` 也補上這兩個行政區。
3. **頁尾補商家資料與地圖** — 新增 `.business-section`：商家名稱、地址、電話、LINE ID，
   加 Google Maps 嵌入地圖（免 API key 的 `output=embed`，`loading="lazy"`）與「在 Google 地圖開啟」按鈕。
4. **套用正向評論** — 新增 `.reviews-section`，逐字引用兩則有明確作者與時間的 Google 評論，
   加上「4.5 / 31 則評論」與「在 Google 查看全部」連結。

> ⚠️ **評論只放文字，絕不加 `Review`／`AggregateRating` 到本站 JSON-LD。**
> 自家網站對自家服務標星等屬 self-serving markup，Google 會取消 rich result 甚至人工處罰。
> 星等要讓 Google 從商家檔案自己顯示。已在 `main.jsx` 的 `googleReviews` 上方加註解提醒。
> 這同時補上了首次稽核指出的「說服段零社會證明」。

另外順手刪了 `cases/rental-clearance/`（1.90 MB，與 `case-20260909` 逐位元組相同的死資產）。

#### 四、首頁 JSON-LD 補強（GEO 實體錨定）

補上 `@id`、`image`、`address`（含郵遞區號與國別）、`geo` 座標、`hasMap`，
`areaServed` 由字串陣列改為 `AdministrativeArea` 物件，`sameAs` 由單一字串改為三筆
（Google 商家、FB 粉專、LINE）。**`sameAs` 指向 Google 商家是 GEO 的關鍵**——
讓 AI 搜尋引擎能把網站與那個 4.5 星商家實體連起來。

#### 五、驗證

- `pnpm lint` 0 error；`pnpm build` 通過；JSON-LD 以 `json.loads` 驗證合法，
  並程式化確認**未含 `review`／`aggregateRating` 欄位**。
- 390px 實測：服務區域 6 項（林口／龜山帶「最常到府」標記）、評論區 2 則、
  商家區地址正確、地圖 iframe 存在且 `loading="lazy"`、無水平溢出。
- 案例頁實測：裝潢細清 **15 → 10 張**、特殊清潔 **13 → 18 張／共 3 個相簿**、總數仍 58。
  **張數自動計算的設計在這次改分類時完全不用手改**，驗證了上一輪的作法。

#### 六、本輪明確未驗

- **地圖 iframe 只在本機 preview 驗過 DOM 與尺寸，沒看到實際地圖圖磚**（Browser pane 隱藏，
  無法捲動到該區截圖）。上線後請確認地圖確實顯示正確位置。
- 未測地圖 iframe 對首屏效能的影響（已加 `loading="lazy"`，但未量測）。
- 未在真機／LINE 內建瀏覽器測新區塊。
- 評論只取到 2 則有完整作者與時間的；Google Maps 頁面只載入部分評論，
  若要再增加請由業主從商家後台提供。
- **`https://jjf.tw/` 全站仍無法以 HTTPS 存取**，所有線上驗證都走 http。

### 2026-09-11 Codex 準備接入自有網域 `jjf.tw`

**業主需求**：已在 GoDaddy 購買 `JJF.tw`，需要協助完成 GoDaddy DNS、GitHub Pages custom domain 與網站路徑設定。

**修正**：

1. `vite.config.js` 的 `base` 從 `/0983531549/` 改為 `/`，讓正式站可部署在 `https://jjf.tw/` 根目錄。
2. `index.html`、`cases/index.html`、`share/index.html` 的 canonical、`og:url`、`og:image`、`og:image:secure_url`、`twitter:image` 全部改為 `https://jjf.tw/...`。
3. `index.html` JSON-LD 補上 `"url": "https://jjf.tw/"`。
4. `share/index.html` 的 JS 轉址與 fallback 連結從 `/0983531549/` 改為 `/`，避免 LINE 分享入口在自有網域下轉錯路徑。
5. `public/sitemap.xml` 改列 `https://jjf.tw/` 與 `https://jjf.tw/cases/`，`lastmod` 更新為 `2026-09-11`。
6. `public/robots.txt` 改為根網域路徑：`Disallow: /cases/manage/`、`Sitemap: https://jjf.tw/sitemap.xml`。

**驗證**：

- `pnpm lint` 通過。
- `pnpm build` 通過；`dist/` 內資源路徑輸出為 `/assets/...`，不再依賴 `/0983531549/`。
- `rg "campcool.github.io/0983531549|/0983531549/" dist` 無命中。
- 本機 preview `http://127.0.0.1:4173/` 首頁載入正常，導覽案例入口為 `/cases/`。
- 本機 preview `http://127.0.0.1:4173/cases/` 載入案例頁正常。
- 本機 preview `http://127.0.0.1:4173/share/` 會自動回首頁 `/`。

**本輪明確未驗**：

- GoDaddy DNS 記錄是否已成功儲存、傳播完成。
- GitHub Pages custom domain `jjf.tw` 是否已通過 DNS check。
- GitHub Pages HTTPS 憑證是否已簽發並可勾選 Enforce HTTPS。
- LINE／Facebook 分享快取是否已重抓新版 OG。
- Google Search Console sitemap 提交，仍需業主帳號操作。

### 2026-09-11 Claude 處理 Codex 覆審的兩個 P2 — ⚠️ 請 Codex 再覆審

Codex 覆審 `1642054` 的結論是「未發現阻斷問題，兩個 P2」，兩項都成立，已修。

#### P2-1：`tools/watermark-cases.ps1` 的 mapping 仍指向已刪相簿

**Codex 的描述正確，但實際影響比描述的更大。** 除了「重跑會復活已刪的
`parking-floor-cleaning/`」之外，還有一個沒被指出的問題：
**`floor-waxing` 在腳本裡根本沒有 mapping**。也就是說清空 `public/cases/` 重跑腳本後，
前台正在用的 `floor-waxing/` 五張**不會被重建**，案例頁會 404。
現有那五張是 `e9fd7d4` 手動複製進去的，一直不在腳本的產出路徑上。

**修法**：腳本的 `Folder` 是業主本機的**來源**目錄、`Slug` 是**輸出**目錄，兩者不必同名。
所以保持 `Folder`（停車位與地板清潔）不動，只把 `Slug`／`Prefix` 改為 `floor-waxing`、
`Label`（浮水印文字）改為「洗地打蠟」。重跑後會從同一批來源照片產出正確的相簿，
也不會再產生 `parking-floor-cleaning/`。

⚠️ **副作用（需業主知情）**：現有五張的浮水印文字仍是舊的「停車位與地板清潔」，
因為它們是複製來的。下次重跑腳本才會換成「洗地打蠟」。若要現在就換，
需要業主提供 `SourceRoot` 重跑：
`pwsh tools/watermark-cases.ps1 -SourceRoot <來源根目錄> -OutputRoot public/cases`

**這是我上一輪的疏漏**：刪除死資產前只掃了前台原始碼，沒掃 `tools/`。已寫成陷阱 11。

#### P2-2：深連結 `/cases/#floor-waxing` 不會自動捲到相簿

**成立。** 原因是瀏覽器的原生錨點捲動發生在解析 HTML 當下，那時 React 還沒 render，
`#slug` 對應的 `<section>` 尚不存在，之後瀏覽器也不會重試。抽屜本身會展開
（`useState` 初始值就吃了 hash），只有捲動缺席。

**修法**：`scrollAlbumIntoView` 移到模組層級（它不依賴任何元件狀態，
留在元件內會讓 `useEffect` 的 exhaustive-deps 出問題），並在 mount 的 effect 內
判斷 hash 有效時補呼叫一次。

**為什麼 `hashchange` 路徑不需要同樣處理**：同頁改 hash 時 section 已存在，
瀏覽器原生錨點捲動本來就有效，不必重複捲。

#### 驗證

- `pnpm lint` 0 error 0 warning；`pnpm build` 通過。
- `tools/watermark-cases.ps1` 以 PowerShell AST parser 檢查語法無誤；
  mapping 解碼實測為 Folder=`停車位與地板清潔`／Slug=`floor-waxing`／Label=`洗地打蠟`。
- 深連結 `/cases/#floor-waxing` 進站：抽屜 `aria-expanded=true`、5 張圖已載入。
- **以 spy 攔截 `Element.prototype.scrollIntoView`**，確認 `scrollAlbumIntoView`
  以正確參數（`{behavior:'smooth', block:'start'}`）呼叫正確的 section
  （矩陣點擊→`mold-removal`、抽屜點擊→`grease-kitchen`）。
- 檢查 build 產物確認初始捲動邏輯沒被 tree-shake：`n&&y(n)` 存在於 `useEffect` 內。

#### 本輪明確未驗

- **深連結的捲動「實際位移」仍未驗到**。我的環境 Browser pane 隱藏，
  `window.innerHeight` 為 0、`window.scrollTo(0,1500)` 無效，
  只能驗到「函式以正確參數被呼叫」，驗不到「畫面真的捲過去」。
  **請 Codex 或業主在真機／可見瀏覽器開 `/cases/#floor-waxing` 確認。**
- 未重跑浮水印腳本（沒有 `SourceRoot`），所以 mapping 的正確性是靜態檢查，
  不是實際產出驗證。
- 仍未做：iOS／Android LINE 真機、iPhone SE 667px、VoiceOver／TalkBack。

### 2026-09-10 Claude 複驗 `e9fd7d4` 並修正三項 — ⚠️ 請 Codex 覆審

**複驗結論：未發現阻斷問題。** Codex 本輪四項核心修正實測全部通過，另修掉三個衍生問題。

#### 一、複驗 Codex `e9fd7d4`

| 檢查項 | 結論 | 依據 |
|---|---|---|
| header 只剩粉專 | ✅ 已修，**根因診斷正確** | 見下方「根因驗證」 |
| 360／375／390／430px | ✅ 全通過 | 四寬度皆無水平溢出；三顆鈕 **46×46**（＞WCAG 44×44），互不重疊 |
| LINE 首屏擁擠 | ✅ 明顯改善 | 四大矩陣底部 **779 → 616px**（−163）；LINE CTA **385 → 260px**；header **73 → 64px** |
| 四大矩陣展開 | ✅ 展開正確 | 4/4 正確設 hash、`aria-expanded=true`、同時僅 1 個抽屜開啟 |
| 裝潢細清命名 | ✅ 案例頁無殘留 | `grep "一般清潔" src/cases.jsx` 為空 |
| 長標題換行 | ✅ 無逐字直排 | `word-break: keep-all`＋`writing-mode: horizontal-tb`；375/390/430 實測「廚房重油汙」「重水地區水垢處理」「商業廚房清潔」皆 1 行 |
| 無障礙／lazy／鍵盤 | ✅ 無退步，**兩處改善** | 四大矩陣由 `div` 改 `<button>`（可鍵盤操作）；header 三顆補 `aria-label`。`aria-controls` 9/9、初始 0 抽屜展開、0 張案場圖下載、0 個負 tabindex |

**根因驗證**（我一度誤判 Codex 診斷有誤，實測後撤回）：
`grid-area` 只在父容器是 grid 時生效，我在 `f1e24f3` 看到父層是 flex，因此懷疑那是無效宣告。
實際 build `1188538` 重現後證實 Codex 正確——該版把 `.header-actions` 改成 `display: grid`，
三顆按鈕 box 完全相同（`l:320, r:356, w:37`）、`重疊: true`，截圖右上角只看得到粉專。
詳見陷阱 10。

#### 二、Claude 本輪修正

1. **四大矩陣張數與點開內容不符（3/4 格）** — 標「重點清潔 14 張」點進去只有 5 張；
   「裝潢細清 15 張」→ 10 張；「特殊清潔 13 張」→ 6 張。原因是 `count` 寫死為分類總和、
   `target` 卻只指向單一相簿。改為從 `albums` 推算，並新增「共 N 個相簿」提示，
   讓訪客知道同分類還有其他相簿。**業主指定的「重點清潔 → `#floor-waxing`」已保留**
   （`featuredCategoryMeta` 可覆寫 target）。見陷阱 9。
2. **商業廚房分類標籤不一致** — 四大矩陣當它是獨立分類，但 `albums` 裡 `category` 是「重點清潔」，
   展開後 eyebrow 顯示「重點清潔」與剛點的標籤不符。已改為 `category: '商業廚房'`。
3. **刪除 `cases/parking-floor-cleaning/`（1.60 MB）** — 與 `floor-waxing/` 五張 SHA-256 逐位元組相同，
   且改名後已無任何引用。C3 死資產清單已重新盤點更新。

**驗算**：改成自動計算後，四分類為裝潢細清 15／重點清潔 14／特殊清潔 13／商業廚房 16，
**總計 58 張，與原本硬編碼完全一致**，證明計算邏輯正確且數字本來就對，錯的只是與 target 的對應。

#### 三、未處理（已列待辦 E1，需業主決定）

首頁「一般清潔」（退租入住／大掃除／清運）在案例頁沒有對應相簿；首頁大類叫「裝潢清潔」、
案例頁相簿叫「裝潢細清」。這屬於業務分類決策，不自行更動。

#### 四、本輪明確未驗

- **捲動行為完全沒驗到**：Browser pane 處於隱藏狀態，連 `window.scrollTo(0, 3000)` 都無效，
  是環境限制而非網站問題。`scrollIntoView` 的程式碼層面檢查合理
  （`<section id>` 永遠在 DOM、`scroll-margin-top: 86px`、`html { scroll-behavior: smooth }`、
  `setTimeout(0)` 排在 React commit 之後），但**必須真機複驗**。
- **`.site-shell` 有 `overflow-x: hidden`**，computed 為 `overflow: hidden auto`，使其成為候選捲動容器。
  目前 `scrollHeight === clientHeight` 所以無害，但 `scrollIntoView` 在 nested scroll container 下，
  **iOS WebView 行為與桌面 Chrome 有已知差異**——這正是上一項需要真機驗的技術原因。
- 未在真機 LINE 內建瀏覽器測（iOS／Android 各一）。
- 未測 iPhone SE 等 667px 短螢幕（推算四大矩陣會被切一排，但 LINE CTA 仍完整可見）。
- 未用真實螢幕閱讀器（VoiceOver／TalkBack），只驗 DOM 與 ARIA 屬性正確性。
- 未看到抽屜展開後的照片網格視覺（環境無法捲動）。
- **未確認 `floor-waxing` 的照片內容是否真的是打蠟工程**——那是停車位／地板清潔的原始照片，需業主確認語意相符。

### 2026-09-10 Codex 重整案例頁手機版與洗地打蠟相簿

**業主回饋**：

- LINE 內建瀏覽器開案例頁時，右上角只剩粉專，頁面文字與圖片過於擁擠。
- 案例頁的「一般清潔」實際都是裝潢細清，應改掉整個大項。
- 重點清潔細項需新增「洗地打蠟」。

**修正**：

1. 找到右上角只剩粉專的根因：`.header-action` 被錯誤設定 `grid-area: actions`，導致 LINE／電話／粉專三顆按鈕在 `.header-actions` 內全部疊到同一格，最後只看得到粉專。本輪已移除該錯誤規則。
2. 案例頁手機 header 降為 64px，右側固定三顆 46px 聯絡按鈕（LINE／電話／粉專），並補上 `aria-label`。
3. 案例頁 hero 手機版縮短：降低 H1 字級、縮短說明文案、手機隱藏「回首頁」次要按鈕，改由 logo 回首頁。
4. 四大分類手機版固定 2×2，不再做上下錯位；「一般清潔」改為「裝潢細清」。
5. `general-cleaning` 與 `case-20260909` 前台文案分類改為裝潢細清。
6. 新增 `public/cases/floor-waxing/`，使用既有已壓縮且有潔淨坊浮水印的停車位／地板清潔照片複製為 5 張 `floor-waxing-*.jpg`。
7. 前台相簿入口由「停車位與地板清潔」改為「洗地打蠟」，避免同一批照片在兩個相簿重複曝光；首頁重點清潔項目同步改成洗地打蠟。
8. 相簿抽屜手機版改為 3 欄 2 列排版，長標題不再被「icon＋張數＋箭頭」擠成直排；桌面保留原本寬版佈局。

**驗證**：

- `pnpm lint` 通過。
- `pnpm build` 通過。
- Chrome viewport 量測：案例頁 header 三顆按鈕分別顯示，LINE x=288、電話 x=339、粉專 x=390，未再重疊。
- Chrome viewport 量測：點擊「重點清潔」會導到 `#floor-waxing`，展開 5 張照片。
- Chrome viewport 量測：`廚房重油汙` 抽屜標題寬 268px、高 39px，未再被擠成逐字直排。

**本輪明確未驗**：

- 未在真機 LINE 內建瀏覽器實測，只用 Chrome viewport 模擬窄版。
- 新增洗地打蠟相簿素材來自既有停車位／地板清潔照片；目前未找到獨立「磁磚清潔打蠟」資料夾或可明確命名的額外素材。

### 2026-09-10 Codex 更新 OG 分享圖

**業主回饋**：LINE 分享預覽圖仍缺少記憶點，圖片本體沒有明確呈現服務地區與服務內容；同時詢問正式網址不帶 `?v=` 是否會連不到或顯示舊版。

**說明**：

- `?v=<commit>` 只是 cache busting 參數，用來讓瀏覽器或聊天軟體把同一頁視為新 URL；正式網址仍是 `https://campcool.github.io/0983531549/`。
- LINE／FB 會快取 OG 預覽。一般客戶不用帶 `?v=` 也能連到網站，但聊天預覽可能沿用舊圖一段時間；要立刻測新版預覽時才加 `?v=`。

**修正**：

1. 新增 `scripts/generate-og.ps1`，用既有 Logo 與實拍照產出 1200×1200 JPG，避免手工改圖無法重現。
2. 新增 `public/og-cleaning-area-services-20260910.jpg`：圖面大字包含「基隆｜台北｜新北｜桃園」，並列出「居家清潔、裝潢細清、退租入住、重油汙、特殊清潔」；檔案約 199KB。
3. `index.html`、`cases/index.html`、`share/index.html` 的 `og:image`、`og:image:secure_url`、`twitter:image` 全部改指向新版圖檔，`og:image:alt` 同步更新。

**注意**：若 LINE 對正式首頁 URL 已快取舊 OG，即使換圖檔也可能暫時不重抓。測試新版預覽請先用 `?v=<最新 commit>`；正式對外仍可給乾淨網址。

### 2026-09-10 Codex 調整桌面 header 視覺密度

**業主回饋**：桌面版導覽膠囊內留白太多，右上角 LINE／粉專按鈕希望「圖大、文字小」。

**修正**：

1. 桌面 `.desktop-nav a` 的最小高度由 48px 改為 42px，左右 padding 改為更窄的 clamp，讓膠囊更接近文字寬度。
2. 桌面 `.desktop-nav` gap 改為較小的 clamp，保留分隔感但減少整排寬度。
3. `1180px` 以上原本又把每顆導覽強制成 `min-width:132px`，已改為 `width:max-content`，避免大螢幕膠囊內留白回彈。
4. `.header-action` 改為直向排列：24px 品牌圖示在上，小字標籤在下，避免文字與圖示同權重造成按鈕過寬。
5. 不新增導覽項目、不更動 LINE／FB 連結、不改行動版底部 dock 結構。

**驗證**：

- `pnpm lint` 通過。
- `pnpm build` 通過（sandbox 內仍會因 Windows/esbuild 權限失敗，改用已授權方式重跑成功）。
- 本機瀏覽器量測 1265px client width：導覽單顆約 92px（原 132px）、右上按鈕 62px、圖示 24px、文字 12px；無水平 overflow。

### 2026-09-10 Codex 覆審並修正 820–1279px 固定聯絡入口

**覆審發現**：Claude 的 `@media (min-width: 820px)` 先把 `.mobile-contact-dock` 設為 `display:none`，後面的
`@media (min-width: 820px) and (max-width: 1279px)` 又把 `.header-actions` 收起。結果首頁在 820–1279px
沒有右上 LINE／粉專，也沒有底部 LINE／電話／粉專 dock，與本檔原寫的「底部 dock 已提供聯絡動線」相反。

**修正**：

1. `.mobile-contact-dock` 與 `.site-shell` 的桌面規則改到 `@media (min-width: 1280px)` 才套用。
2. `820–1279px` 首頁維持底部 dock，承接固定聯絡動線。
3. `820–1279px` 案例頁保留右上聯絡鈕，並隱藏底部 dock，避免同一段寬度出現重複固定聯絡入口。
4. `style.css` 的斷點註解改為 820–1279，不再保留「取 1400 為界」的舊說法。

**驗證**：

- `pnpm lint` 通過。
- `pnpm build` 通過（sandbox 內首次因 Windows/esbuild 權限失敗，改用已授權方式重跑成功）。
- `git status --short` 乾淨後才進行 commit。

### 2026-09-10 修首頁 header 導覽與聯絡鈕重疊（Claude）— ⚠️ 請 Codex 覆審

**業主回報**：首頁上方導覽最後一項與右側 LINE／粉專按鈕重疊。**這是既有 bug，不是本日任何一批改動造成的。**

**成因**（實測 900px）：

桌面版（`min-width: 820px`）的 header 是
`grid-template-columns: auto minmax(0, 1fr) auto` / `"brand nav actions"`，grid 佈局本身正確
（nav 欄 209–639、actions 647–840，兩者不重疊）。問題在 **`.desktop-nav a` 有 `min-width: 116px`**：
6 個膠囊硬要 721px，而 `minmax(0, 1fr)` 的欄位只給得出 430px，膠囊便畫到欄位外，
最後一項「服務地區」跑到 814–930，直接蓋住 647 起的聯絡鈕。
`.desktop-nav` 的 `overflow-x: auto` 則會生出橫向捲動條——那正是先前 `4dc02a3`
「fix: remove mobile nav horizontal scroll」修掉過的東西，在桌面版又長回來。

**改法**（三項，第 2、3 項經業主同意「logo 可以縮小靠左一點」）：

1. `.desktop-nav a` 拿掉 `min-width: 116px`（改 `auto`），padding 與 font-size 改用
   `clamp()` 隨視窗流動，窄桌面自動收斂。
2. **logo 縮小**：桌面版 `.brand-logo` 由 `clamp(156px, 16vw, 204px)` 改為
   `clamp(140px, 12vw, 176px)`，`max-height` 82 → 74px。
3. **header 頁緣收窄（靠左）**：`.site-header` 左右改用 `clamp(24px, 3vw, 48px)`，
   比內文的 `--site-padding`（上限 64px）窄，1280px 時左右各省約 26px。
   header 因此不與內文切齊，這是業主同意的取捨。
4. 新增 `@media (min-width: 820px) and (max-width: 1279px)`：header 改回兩欄
   `"brand nav"`，`.header-actions` 收起。Codex 覆審後已補正：底部 dock 必須在此區間保留，1280px 起才隱藏。

**斷點怎麼收斂到 1280 的**（過程留著，避免下次又猜）：

膠囊字級在 1308px 後達 clamp 上限 17px，導覽自然寬固定。同列還要放 logo、聯絡鈕、
gap 與頁緣。第一輪只改膠囊時，實測 1280px 重疊 39px、1360px 仍溢出 7px，
必須把界拉到 1400——但 1280×800 與 1366×768 都是常見筆電，落在收起區很可惜。
第二輪縮 logo（省約 38px）讓 1366 過關（間距 18px），但 1280 仍差 27px；
第三輪收窄 header 頁緣（省約 51px）後 1280 只剩 2px 溢出、間距 6px，太邊緣；
第四輪 logo 由 13vw 再收到 12vw（1280 時再省 13px），1280 才真正過關。
**最終 1280 與 1366 都能與聯絡鈕同列顯示，界收在 1280。**

**實測**（首頁，`need` = 導覽自然寬，`have` = 欄位可用寬，兩者相等即無溢出）：

| 寬度 | 聯絡鈕 | logo 寬 | need / have | 溢出 | 碰撞 | 與按鈕間距 |
|---|---|---|---|---|---|---|
| 375 | 收起（行動版） | — | 221 / 221 | 無 | 無 | — |
| 820 | 收起 | 140 | 608 / 608 | 無 | 無 | — |
| 1024 | 收起 | 140 | 799 / 799 | 無 | 無 | — |
| 1279 | 收起 | 153 | 1026 / 1026 | 無 | 無 | — |
| **1280** | **顯示** | 154 | 826 / 826 | 無 | 無 | **13px** |
| **1366** | **顯示** | 164 | 896 / 896 | 無 | 無 | **47px** |
| 1920 | 顯示 | 176 | 1424 / 1424 | 無 | 無 | 311px |

- 案例頁**不受影響**：`.cases-page .header-actions`（specificity 0,2,0）勝過新規則的
  `.header-actions`（0,1,0），900px 實測聯絡鈕仍顯示、無碰撞、header 84px。
- 行動版不受影響：改動全在 `min-width: 820px` 之內。

**本輪明確未驗**：

- 未在真實 1280／1366 實機上看過，只用瀏覽器視窗模擬。
- 1280px 的間距 13px 偏緊，若日後導覽增加項目或文字變長會再度相撞；
  **加導覽項目前請重跑一次上表的量測**。
- 未評估 logo 縮到 154px（1280 時）對品牌辨識度的影響，這屬業主主觀判斷。

### 2026-09-10 移除案例頁 header 相簿導覽（Claude，業主指定）— ⚠️ 請 Codex 覆審

**業主回報**：案例頁上方那排導覽「蠻不喜歡但不知道怎麼改」。診斷後由業主選定「直接移除」。

**移除的理由**（三個問題疊在一起）：

1. **配色是借來的，與內容無關**。`.nav-album-1~9` 直接沿用首頁區塊導覽的色票
   （`.nav-needs` / `.nav-services` / …），所以「特殊清潔 除霉」是綠的、「廚房重油汙」是橘的，
   純粹因為排第幾個。顏色不攜帶資訊，眼睛卻一直想找規律——這是視覺雜亂的主因。
   附帶：`.nav-album-3` 與 `.nav-album-5` 各被定義了兩次。
2. **標題長度 3～13 字**（「洗雨棚」vs「20260909 案場紀錄」），硬排 3×3 網格必然參差，
   375px 下文字重疊溢出。
3. **與下方「案場相簿索引」做同一件事，而且做得比較差**。索引卡有分類、張數、圖示，
   上面這排只有裸標題。同一頁用兩個區塊做同一個導覽。

**改法**：

- `cases.jsx` 移除 `<nav className="desktop-nav">` 整塊。
- `style.css` 新增 `.cases-page` 基礎層規則：header 收成單列 `"brand actions"`，
  `--header-height: 72px`（桌面 84px），並讓 `.cases-page .header-actions` 在所有斷點顯示
  （原本行動版是 `display:none`，移除導覽後 header 會太空）。
- 刪除 media query 內的 `.cases-page .desktop-nav` 與 `.cases-page .desktop-nav a`。
- 清除 11 條 `.nav-album-*` 規則與 `:target` 高亮清單中的 9 行。
  **注意**：這些規則與首頁的 `.nav-needs` 等共用選擇器，只能拆開，不能整條刪。

**實測**：

| 斷點 | header 高 | 導覽 | 水平溢出 |
|---|---|---|---|
| 375 | 132px → **75px** | 已移除 | 無（原本文字重疊已消失） |
| 768 | 132px → **81px** | 已移除 | 無 |
| 桌面 | 132px → **77px** | 已移除 | 無 |

- 首頁**未受影響**：導覽仍在、6 個連結、6 個配色各自獨立且全不同、header 維持 104px。
- `pnpm lint` 0 error；`pnpm build` 成功。
- CSS 結構檢查：大括號 409/409 平衡、無孤兒選擇器、`nav-album` 殘留 0 處。

**⚠️ 施工過程的教訓（給下一個 AI）**：我第一次用腳本批次刪 `nav-album` 時，
腳本從「含 nav-album 的那一行」開始收集選擇器，沒有往回抓同一條規則的前置選擇器行，
結果把 `.desktop-nav .nav-needs,` 這類共用規則整條刪掉、留下孤兒選擇器，
會讓首頁 6 個導覽全部套到同一個顏色。已 `git checkout` 還原後改用逐條精確替換。
**共用選擇器清單不要用腳本批次處理。**

**本輪明確未驗**：

- 未確認移除導覽後，是否有使用者仰賴那排快速跳轉（無分析數據可查）。
- 未測 1440px 以上的寬螢幕。

### 2026-09-10 複驗 Codex 三批＋修正三處（Claude）— ⚠️ 請 Codex 覆審

**一、複驗 Codex `aeabee6` / `0590fb0` / `2251288`**

| 待辦 | 結論 | 依據 |
|---|---|---|
| A1 FAQ | ✅ 通過 | 新文案承認案例頁有實拍相簿，同時守住內容邊界 |
| A2 LINE 對比 | ✅ 通過，且比要求更完整 | 四顆按鈕實測：Hero／聯絡卡／dock 皆 **5.47:1**；header 小鈕 **4.74:1**（改前 2.09:1，此顆原本沒列進待辦，Codex 自己補了） |
| C1 caseAdmin | ✅ 通過，做法優於建議 | 改用 `Promise.allSettled` 並行處理，單張失敗不影響其他，另加「N 張失敗」提示 |
| B2 robots/sitemap | ❌ **假綠，已改回 ⬜** | robots.txt 放子路徑對爬蟲無效，實測見陷阱 7 |

**二、Claude 本輪修正**

1. **`handoff-fixes.css` 併回 `style.css` 並刪除該檔**（原檔覆寫有效，但有兩個副作用）
   - `style.css:13` 的舊值 `#06c755` 還留在原地，下一個人讀 style.css 會被誤導——正是本檔陷阱 3 警告的漂移模式，只是搬進了 CSS 內部。
   - **打包 chunk 命名被污染**：189 KB 的 React runtime 原本叫 `style-*.js`，變成 `handoff-fixes-*.js`。已還原。
   - 順手發現 `.line-contact-card` 另有硬編碼的舊綠漸層，只改變數會漏掉（已記為陷阱 8）。
2. **修 `aria-controls` 指向不存在的元素（9/9）**：`album-photo-grid` 容器改為永遠留在 DOM，用 `hidden={!isOpen}` 控制，內容仍條件式渲染，**lazy 效益完全保留**。另加 `.album-photo-grid[hidden]{display:none}`，因為 `display:grid` 會蓋過 `[hidden]` 預設值。
3. **修 `aria-hidden` 藏掉資訊性內容**：hero 分類卡由 `div` 改為 `ul/li` 並移除 `aria-hidden`、加 `aria-label`；索引卡的 `album-index-icon-panel` 移除 `aria-hidden`，只在裝飾性 icon 上保留。CSS 補上 list reset 以免 `ul` 預設縮排破版。

**三、實測驗證**（本地 build 產物，靜態伺服器）

- `pnpm lint` 0 error 0 warning；`pnpm build` 成功，chunk 名已還原為 `style-B6zZGKp5.js`
- `aria-controls` 目標存在：**9/9**（修正前 0/9）
- 抽屜關閉時：`hidden=true`、`display:none`、內部 `<img>` **0 張** → lazy 效益確認保留
- 點開後：`aria-expanded=true`、`hidden=false`、`display:grid`、3 張圖**全部帶 `loading="lazy"`**、同時僅 1 個抽屜開啟
- 鍵盤：觸發元素為 `<button>`，可聚焦、可按 Enter
- 深連結 `#grease-kitchen` 直接開啟頁面會正確展開該相簿
- 分類卡可讀文字已恢復：「一般清潔 15 張 重點清潔 14 張 特殊清潔 13 張 商業廚房 16 張＋影片」
- 375／桌面截圖版面正常，`ul` 改動未破版

**四、本輪明確未驗**

- 未用真正的螢幕閱讀器（NVDA／VoiceOver）測，只驗了 DOM 與 ARIA 屬性正確性
- 未截到抽屜展開後的完整視覺（捲動指令未生效）；但該區塊 CSS 未改動，樣式與 `c2f7fbd` 相同
- 未測 768 斷點（本輪只測 375 與桌面）
- 未跑 Lighthouse

**五、⚠️ 給 Codex 的覆審重點**

1. `.album-photo-grid` 改用 `hidden` 屬性——請確認在你測過的裝置上，關閉時沒有殘留空白間距（`.case-album-section` 的 gap 可能仍計入）。
2. hero 分類卡改成 `ul/li`——請確認 `.hero-category-card:nth-child(n)` 的 `translateY(18px)` 交錯效果在 `li` 上仍如你原本設計，尤其 768 斷點。
3. 四張分類卡的張數（15／14／13／16）**是硬編碼**，目前正確（合計 58），但 `albums` 一改就會漂移。建議改成從 `albums` 計算，你來決定要不要動。
4. `caseAdmin` 的 SHA-256：實測 hash 就是 `SHA-256('1549')`，4 位數字空間全掃 10000 組僅需 **0.001 秒**（第 1550 組破出）。hash 也仍在公開 bundle。功能無妨（工具不碰後端），但**別讓它看起來像有保護**——本檔陷阱 4 的說明已足夠，這裡只是提醒不要再往「加強加密」的方向投資。
5. B2 請不要再嘗試用 `public/robots.txt` 解決——那個路徑先天無效，見陷阱 7。

### 2026-09-10 修正首批阻斷項（Codex，基準 `aeabee6`）— 已驗 lint/build

依本檔待辦先修 A1、A2、B2、C1：

- A1：改寫首頁 FAQ 第 3 題，讓案例頁實拍相簿與內容邊界一致。
- A2：LINE CTA 色票已併回 `src/style.css`，使用 `#017A35` / `#006B2E`，避免白字對比不足；不要再恢復 `handoff-fixes.css`。
- B2：新增 `public/robots.txt` 與 `public/sitemap.xml`；管理工具路徑列為 disallow，sitemap 只列公開首頁與案例頁。
- C1：`caseAdmin.jsx` 移除明文 `1549` 比對，改 hash 檢查；`handleFiles` 改 `Promise.allSettled` 與 `try/finally`，避免單張照片失敗後 UI 卡住。

**驗證**：

- `pnpm lint` 通過。
- `pnpm build` 通過。第一次在受限沙箱內 build 被 Windows 權限擋住，已用外部執行重跑成功。
- `rg` 檢查未再看到 `const password`、`code === password`、舊 LINE 色值或舊 FAQ 文案。

**本輪明確未驗**：

- 未開瀏覽器做 375／768／桌面截圖。
- 未實測 LINE/電話點擊。
- 未送 Google Search Console；B2 仍標 🟨。
- 未處理 B1/B3/B4/C2/C3/D1。

### 2026-09-10 手機導覽與案例頁聯絡／分類互動修正（Codex，基準 `3b423cb`）— 待線上複驗

依使用者手機截圖回饋修正三項：

- 首頁手機導覽膠囊改為固定 3×2 欄列比例：降低 logo/header 高度、鎖定 nav item 高度 32px、中文字不再換行撐破膠囊。
- 案例頁移除下方 `MobileContactDock`，避免與頁首聯絡入口重複並吃掉手機閱讀區域；頁首改為 LINE／電話／粉專三個圖示優先按鈕。
- 案例頁四大矩陣分類由純展示卡改成可點擊按鈕，會展開並平滑捲動到對應相簿：一般清潔、重點清潔、特殊清潔、商業廚房。

**本輪驗證**：

- `pnpm lint` 通過。
- `pnpm build` 通過。

**本輪明確未驗**：

- 尚未用真機 LINE 內建瀏覽器驗證頁首三按鈕與導覽高度。
- 尚未實測四大矩陣在手機點擊後的捲動位置是否完全符合使用者手感。

### 2026-09-10 AI Skills 交接規則確認（Codex，基準 `fc64ce8`）— 文件校正

依使用者指定讀取 `D:\AI-Skill\ai-skills\SKILL.md`，並依路由選擇主技能
`D:\AI-Skill\ai-collaboration-handoff\SKILL.md`。判斷結果：

- `ai-skills` 本體內容完整，與使用者貼上的內容一致，暫不需要修正。
- `ai-collaboration-handoff` 預設要求 `AI-HANDOFF.md`，但本專案 `AGENTS.md` 已明確指定
  `AI-README.md` 為唯一 AI 協作交接文件，因此不另建 `AI-HANDOFF.md`，避免雙軌交接。
- 本檔先前仍寫 `main` 最新為 `bbfde70`，但實際 GitHub main 已是 `fc64ce8`；
  本輪已校正交接狀態與進度紀錄。

**本輪明確未驗**：

- 未修改網站功能、樣式或資產。
- 未跑 `pnpm lint` / `pnpm build`。
- 未重新實測 Claude 稽核列出的 10 項待辦是否仍成立；下一輪若施工需逐項複驗。

### 2026-09-10 14:30 案例相簿改為 lazy drawers（Codex，`c2f7fbd`）— ⚠️ 待複驗

Codex 把案例頁相簿改成摺疊抽屜，並以 `.hero-category-card` 分類卡取代原本的封面圖堆疊。
改動 `src/cases.jsx`（+223/-114 區間）與 `src/style.css`（+238）。

**Claude 尚未複驗此批**，僅確認它沒有動到本檔待辦清單所列的任何位置
（`main.jsx` 的 FAQ 與 scenario 卡、`style.css:13` 的 LINE 色值、`caseAdmin.jsx`），
10 項待辦逐項復驗後**全部仍然成立**。

下一個接手的 AI 請依規則二第 2、3 項複驗這批：

- 案例頁首屏傳輸量是否真的下降（改抽屜前案例頁 `dist/cases` 為 37 MB 級的資產目錄）
- 摺疊抽屜的鍵盤可達性與 `aria-expanded` 狀態
- 375／768／桌面三斷點下 `.hero-category-card` 的 `translateY(18px)` 錯位是否造成重疊

### 2026-09-10 首次轉換稽核（Claude，於 `bbfde70`）— 未動程式碼

**依據**：`D:\AI-Skill` 的 `uiux-design`（含 `claude/uiux-reading-rhythm-2026-08-30` 分支的閱讀節奏章節）
與 `marketing-growth-conversion` 的獲客五段檢查。稽核對象為線上正式站，
已比對線上 bundle hash（`main-Djfm7mdB.js`）與本地 build 產物一致，確認受檢版本即 `bbfde70`。

**五段檢查結論**：

| 段 | 判定 | 主因 |
|---|---|---|
| 1 觸及 | 🔴 阻斷 | 無 robots.txt／sitemap.xml，未接 GSC，仍在 Pages 子路徑 |
| 2 落地 | 🟠 待修 | 首屏最大字是品牌名（92px）而非結論；「多少錢」未答 |
| 3 說服 | 🔴 阻斷 | 零數字錨點；FAQ 與案例頁自相矛盾；無風險逆轉 |
| 4 行動 | 🟠 待修 | CTA 佈局良好（13 個／三階段＋常駐 dock），但主按鈕對比 2.26:1 |
| 5 回流 | 🔴 缺項 | 無任何回訪／推薦機制 |

**實測通過、不需處理的項目**（列出以免下一個 AI 重複查）：

- 靜態資產引用：8 個原始檔解析出 76 筆路徑，逐一比對 `public/` — **0 缺失**，無壞圖
- `pnpm lint` 0 error 0 warning；`pnpm build` 成功（1632 modules）
- 四個入口正確共用 React shared chunk，無重複打包
- 案場影片 `moov` 在位元組 32（`mdat` 在 37233）→ 支援串流即播，**不需要重新編碼**
- 三斷點實測 375／768／桌面版面皆正常
- skip-link、`:focus-visible` 3px 外框、`prefers-reduced-motion` 均已實作
- 所有 `<img>` 帶 width/height → 無 CLS；線上 console 0 錯誤，14 筆請求全 200
- 圖片解析度合理：79 張點陣圖無一超過 2000px
- JSON-LD 未誤用 `Review`／`AggregateRating` — 符合可信度設計規則

**本輪明確「未驗」（不得當成已完成）**：

- 未跑 Lighthouse，無障礙分數未取得基準值
- 未實測動效在低階手機的 fps
- 未驗證繁中文案在各斷點的斷行（DESIGN.md 提過怕斷成「工作／室」）
- 未測 `cases/manage/` 壓縮工具的實際上傳流程
- 未查 Google Ads 素材與 landing page 的用語一致性（目前不確定此站是否有投放）

**完整稽核報告**：https://claude.ai/code/artifact/15c30c86-eda4-47c8-bb8a-0be3dc154e06

### 2026-09-10 之前

本檔案建立前的歷程請看 `git log`。最近一批（皆為 Codex）：
`bbfde70` 相簿整理／`1d0e896` 商業廚房相簿／`98db408` 行動版聯絡改善／`b120e23` LINE 分享預覽頁。

---

## 7. 協作規則

### 規則一：可直推 main，但事後必須互相複驗

此 repo 目前無 PR 流程。推 main 會直接觸發部署，所以：

- 推之前先 `git pull --ff-only origin main`，確認沒有別人的新 commit。
- 推之後在本檔案「進度紀錄」寫清楚**改了什麼、怎麼驗的、哪些沒驗**。
- 下一個接手的 AI 負責複驗上一批，發現問題寫進待辦，不要默默改掉。

### 規則二：這四類變更必須做行為驗證，不能只跑 build

1. **改到 CTA、聯絡方式、LINE／電話連結** → 實際點一次，確認開得起 LINE
2. **改到圖片載入方式** → 量首屏傳輸量，確認沒有反而變重
3. **改到版面／字級／顏色** → 375／768／桌面三斷點實際截圖看
4. **改到 JSON-LD、meta、robots、sitemap** → 用 Rich Results Test 驗，別只看檔案存在

`pnpm build` 成功不等於畫面對。**CI 綠不等於好看、可用。**

### 規則三：改文案前先讀第 2 節「內容邊界」

這是業主的刻意決定。要放寬任何一條，先問業主，不要自己判斷「這樣轉換比較好」。

### 規則四：改設計語言就要同步 DESIGN.md

新配色、新字體、新間距規則落地後，`DESIGN.md` 要一起改。
現在它已經漂移（見陷阱 3），修的人請順手校正。

### 誰做的：從 commit author 分辨

| AI | commit author |
|---|---|
| Claude | `Claude <noreply@anthropic.com>` |
| Codex | `CodexSandboxOffline <...@bh081036.secom.corp>` |
| Manus | `Campcool <...@users.noreply.github.com>`（與業主手動 commit 混在一起，靠訊息風格區分） |

### 分工建議

- **Codex**：實作、重構、批次修改、資產處理（此站歷來 commit 幾乎都是 Codex）
- **Claude**：稽核、複驗、跨站一致性檢查、文案與轉換設計
- 兩邊都要遵守：**不要在對方沒複驗前宣布「已完成」**

---

## 8. 常用指令

```bash
pnpm install          # 安裝依賴
pnpm dev              # 本機開發
pnpm build            # 建置（產出 dist/）
pnpm lint             # ESLint（目前 0 error 0 warning，請維持）
```

部署：push 到 `main` 即自動觸發，無需手動操作。
